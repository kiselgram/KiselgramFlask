// static/js/prem.js — Kiselgram Premium v4.3 Final
(function() {
    'use strict';

    console.log('✨ Kiselgram Premium v4.3');
    console.log('THIS VIEW IS DEAPRECIATED. USE WEB K')

    window.isPremium = true;
    window.PREMIUM_FEATURES = {
        fonts: true, stories: true, wallpapers: true, animatedStickers: true,
        videoAvatars: true, chatStats: true, customNotifications: true,
        largeUploads: true, botApi: true, prioritySupport: true
    };

    let currentUserId = null;
    let currentUserUsername = '';
    let currentUserDisplayName = '';
    let currentUserAvatar = '?';
    let activeChat = null;
    let selectedMembers = [];
    let replyToMessage = null;
    let currentStories = [];
    let currentStoryIndex = 0;
    let currentStoryUser = null;
    let storyProgressInterval = null;
    let offlineQueue = [];
    let isOnline = navigator.onLine;
    const cachedMessages = new Map();

    // Mention autocomplete state
    let mentionState = { active: false, query: '', startPos: -1, users: [], selectedIdx: 0 };

    function getEl(id) { return document.getElementById(id); }
    const DOM = {
        get emptyChat() { return getEl('emptyChat'); },
        get chatView() { return getEl('chatView'); },
        get contactsView() { return getEl('contactsView'); },
        get createGroupView() { return getEl('createGroupView'); },
        get createChannelView() { return getEl('createChannelView'); },
        get chatList() { return getEl('chatList'); },
        get messagesContainer() { return getEl('messagesContainer'); },
        get messageInput() { return getEl('messageInput'); },
        get sendBtn() { return getEl('sendBtn'); },
        get modalRoot() { return getEl('modalRoot'); },
        get searchResults() { return getEl('searchResults'); },
        get globalSearchInput() { return getEl('globalSearchInput'); },
        get replyPreview() { return getEl('replyPreview'); },
        get chatHeaderName() { return getEl('chatHeaderName'); },
        get chatHeaderAvatar() { return getEl('chatHeaderAvatar'); },
        get chatHeaderStatus() { return getEl('chatHeaderStatus'); },
        get storiesRow() { return getEl('storiesRow'); }
    };

    // Utilities
    function debounce(fn, wait) { let t; return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), wait); }; }
    function escapeHtml(s) { if (!s) return ''; const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
    function formatTime(ts) { if (!ts) return ''; const d = new Date(ts), n = new Date(), diff = n - d; if (diff < 60000) return 'Just now'; if (diff < 3600000) return Math.floor(diff/60000)+'m ago'; if (diff < 86400000) return Math.floor(diff/3600000)+'h ago'; return d.toLocaleDateString(); }
    function showToast(msg, type='info') {
        let container = document.querySelector('.toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'toast-container';
            document.body.appendChild(container);
        }
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = msg;
        container.appendChild(toast);
        setTimeout(() => {
            toast.classList.add('removing');
            setTimeout(() => toast.remove(), 250);
        }, 3000);
    }
    window.showToast = showToast;
    function formatFileSize(bytes) { if (!bytes) return ''; if (bytes<1024) return bytes+' B'; if (bytes<1024*1024) return (bytes/1024).toFixed(1)+' KB'; return (bytes/(1024*1024)).toFixed(1)+' MB'; }
    function formatLastSeen(ls) { if (!ls) return ''; const d = new Date(ls), n = new Date(), diff = Math.floor((n - d)/1000); if (diff < 60) return 'just now'; if (diff < 3600) return Math.floor(diff/60)+'m ago'; if (diff < 86400) return Math.floor(diff/3600)+'h ago'; return d.toLocaleDateString(); }
    function formatChatTime(isoString) {
        if (!isoString) return '';
        const d = new Date(isoString);
        const now = new Date();
        if (d.toDateString() === now.toDateString()) {
            return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }
        const yesterday = new Date(now);
        yesterday.setDate(now.getDate() - 1);
        if (d.toDateString() === yesterday.toDateString()) {
            return 'Yesterday';
        }
        return d.toLocaleDateString();
    }

    // Mention autocomplete
    async function showMentionPopup(query) {
        let popup = document.getElementById('mentionPopup');
        if (!popup) {
            popup = document.createElement('div');
            popup.id = 'mentionPopup'; popup.className = 'mention-popup';
            const inputArea = DOM.messageInput?.parentElement;
            if (inputArea) { inputArea.style.position = 'relative'; inputArea.appendChild(popup); }
        }
        if (!query) { popup.innerHTML = '<div class="mention-item" style="justify-content:center;color:var(--text-muted)">Type to search</div>'; popup.classList.add('active'); return; }
        try {
            const r = await fetch(`/api/users?search=${encodeURIComponent(query)}`);
            const data = await r.json();
            let users = data.users || data || [];
            if (activeChat?.type === 'group') {
                const gr = await fetch(`/api/groups/${activeChat.id}`);
                const gd = await gr.json();
                if (gd.success && gd.members) users = gd.members;
                else users = [];
            }
            mentionState.users = users;
            if (!users.length) { popup.innerHTML = '<div class="mention-item" style="justify-content:center;color:var(--text-muted)">No users found</div>'; popup.classList.add('active'); return; }
            popup.innerHTML = users.slice(0, 8).map((u, i) =>
                `<div class="mention-item ${i === mentionState.selectedIdx ? 'selected' : ''}" onmousedown="insertMention(${u.id},'${escapeHtml(u.display_name || u.username)}')">
                    <span class="mention-avatar">${(u.display_name || u.username)[0].toUpperCase()}</span>
                    <span class="mention-name">${escapeHtml(u.display_name || u.username)}</span>
                    <span class="mention-username">@${escapeHtml(u.username)}</span>
                </div>`
            ).join('');
            popup.classList.add('active');
        } catch (e) { popup.classList.remove('active'); }
    }

    function closeMentionPopup() {
        const popup = document.getElementById('mentionPopup');
        if (popup) popup.classList.remove('active');
        mentionState.active = false;
    }

    function insertMention(userId, name) {
        const input = DOM.messageInput;
        if (!input) return;
        const val = input.value;
        const before = val.slice(0, mentionState.startPos);
        const after = val.slice(input.selectionStart);
        input.value = before + '@' + name + ' ' + after;
        input.focus();
        input.selectionStart = input.selectionEnd = (before + '@' + name + ' ').length;
        closeMentionPopup();
        handleMessageInput();
    }

    function completeMention() {
        const users = mentionState.users;
        if (!users.length) return;
        const user = users[mentionState.selectedIdx] || users[0];
        insertMention(user.id, user.display_name || user.username);
    }

    // Copy message to clipboard
    window.copyMessage = async (msgId) => {
        const el = document.getElementById(`msg-${msgId}`);
        const text = el?.querySelector('.message-text')?.textContent || '';
        try { await navigator.clipboard.writeText(text); showToast('Copied!', 'success'); } catch (e) { showToast('Failed to copy', 'error'); }
    };

    // Forward message stub
    window.forwardMessage = (msgId) => {
        enterSelectionMode(msgId);
        showToast('Select a chat to forward', 'info');
    };

    // Initialization
    document.addEventListener('DOMContentLoaded', async () => {
        if ('serviceWorker' in navigator) {
            try { await navigator.serviceWorker.register('/sw.js'); } catch (e) {}
        }
        // Offline indicator banner
        const banner = document.createElement('div');
        banner.className = 'offline-banner'; banner.id = 'offlineBanner';
        banner.textContent = 'No internet connection';
        document.body.prepend(banner);

        await loadCurrentUser();
        await loadChatList();
        await loadStories();
        setupEventListeners();
        loadThemePreference();
        loadFontPreference();
        if (window.currentUserId && !localStorage.getItem('profile_completed')) {
            setTimeout(() => showProfileCompletionPrompt(), 1000);
        }
        if (Notification.permission === 'default') {
            Notification.requestPermission().then(p => { if (p === 'granted') subscribeToPush(); });
        } else if (Notification.permission === 'granted') {
            subscribeToPush();
        }
        const urlParams = new URLSearchParams(window.location.search);
        const chatId = urlParams.get('chat');
        if (chatId) setTimeout(() => openChat('personal', parseInt(chatId)), 500);
        setInterval(loadChatList, 30000);
        setInterval(loadStories, 120000);
        setInterval(() => { if (activeChat) refreshMessages(); }, 5000);
        setInterval(() => { if (activeChat) fetchTypingStatus(); }, 2000);
        setInterval(() => fetch('/api/update_last_seen', { method: 'POST' }), 60000);

        // Keyboard shortcuts
        document.addEventListener('keydown', e => {
            if (e.ctrlKey || e.metaKey) {
                if (e.key === 'k' || e.key === 'K') { e.preventDefault(); DOM.globalSearchInput?.focus(); }
                if (e.key === 'n' || e.key === 'N') { e.preventDefault(); document.querySelector('[onclick*="openCreateGroup"]')?.click(); }
            }
            if (e.key === 'Escape') {
                if (document.querySelector('.lightbox-overlay')) { document.querySelector('.lightbox-overlay')?.remove(); return; }
                document.querySelectorAll('.modal-overlay').forEach(m => m.remove());
                if (mentionState.active) { closeMentionPopup(); }
            }
            if (e.key === 'Tab' && mentionState.active) { e.preventDefault(); completeMention(); }
        });
    });

    window.addEventListener('online', () => {
        isOnline = true;
        const b = document.getElementById('offlineBanner');
        if (b) b.classList.remove('show');
        syncOfflineMessages();
    });

    window.addEventListener('offline', () => {
        isOnline = false;
        const b = document.getElementById('offlineBanner');
        if (b) b.classList.add('show');
    });

    async function loadCurrentUser() {
        try {
            const res = await fetch('/api/profile'); const data = await res.json();
            if (data.success && data.user) {
                window.currentUserId = data.user.id;
                window.currentUserUsername = data.user.username;
                window.currentUserDisplayName = data.user.display_name || data.user.username;
                window.currentUserAvatar = data.user.username[0].toUpperCase();
                updateUI();
                if (data.user.display_name && data.user.bio) localStorage.setItem('profile_completed', 'true');
            }
        } catch (e) {}
    }

    function updateUI() {
        const avatar = getEl('menuUserAvatar'); const name = getEl('menuUserName'); const username = getEl('menuUserUsername');
        if (avatar) avatar.textContent = window.currentUserAvatar;
        if (name) name.innerHTML = `${window.currentUserDisplayName} <span class="premium-badge">PREMIUM</span>`;
        if (username) username.textContent = '@' + window.currentUserUsername;
    }

    function setupEventListeners() {
        getEl('menuBtn')?.addEventListener('click', togglePopoutMenu);
        DOM.globalSearchInput?.addEventListener('input', debounce(handleGlobalSearch, 300));
        DOM.globalSearchInput?.addEventListener('focus', () => DOM.searchResults?.classList.add('active'));
        if (DOM.messageInput) {
            DOM.messageInput.addEventListener('input', handleMessageInput);
            DOM.messageInput.addEventListener('keydown', handleMessageKeydown);
        }
        document.addEventListener('click', (e) => {
            const sc = document.querySelector('.global-search'); if (sc && !sc.contains(e.target)) DOM.searchResults?.classList.remove('active');
            // Close emoji picker on outside click
            const ep = document.querySelector('.emoji-picker');
            if (ep && !ep.contains(e.target) && !e.target.closest('[onclick*="toggleEmojiPicker"]')) {
                ep.classList.remove('active');
            }
        });
        const memberSearch = getEl('memberSearchInput');
        if (memberSearch) memberSearch.addEventListener('input', debounce(handleMemberSearch, 300));

        // ===== FEATURE 8: DRAG-AND-DROP =====
        const mc = DOM.messagesContainer;
        if (mc) {
            mc.addEventListener('dragenter', (e) => {
                e.preventDefault(); e.stopPropagation();
                document.getElementById('dropOverlay')?.classList.add('active');
            });
            mc.addEventListener('dragover', (e) => {
                e.preventDefault(); e.stopPropagation();
            });
            mc.addEventListener('dragleave', (e) => {
                e.preventDefault(); e.stopPropagation();
                if (!mc.contains(e.relatedTarget)) {
                    document.getElementById('dropOverlay')?.classList.remove('active');
                }
            });
            mc.addEventListener('drop', async (e) => {
                e.preventDefault(); e.stopPropagation();
                document.getElementById('dropOverlay')?.classList.remove('active');
                const files = e.dataTransfer.files;
                if (!files.length || !activeChat) return;
                const fi = getEl('fileInput');
                if (fi) {
                    const dt = new DataTransfer();
                    for (const f of files) dt.items.add(f);
                    fi.files = dt.files;
                    handleFileSelect(fi);
                }
            });
        }

        // ===== FEATURE 7: TYPING INDICATOR POLLING =====
        // Already set up via setInterval in init, just update the display
    }

    function handleMessageInput() {
        if (DOM.messageInput && DOM.sendBtn) DOM.sendBtn.disabled = !DOM.messageInput.value.trim();
        if (DOM.messageInput) { DOM.messageInput.style.height = 'auto'; DOM.messageInput.style.height = Math.min(DOM.messageInput.scrollHeight, 100) + 'px'; }
        // Mention autocomplete
        if (DOM.messageInput) {
            const val = DOM.messageInput.value;
            const pos = DOM.messageInput.selectionStart;
            const textBefore = val.slice(0, pos);
            const atIdx = textBefore.lastIndexOf('@');
            if (atIdx !== -1 && (atIdx === 0 || val[atIdx-1] === ' ')) {
                const query = textBefore.slice(atIdx + 1);
                if (!query.includes(' ')) {
                    mentionState.active = true;
                    mentionState.query = query;
                    mentionState.startPos = atIdx;
                    mentionState.selectedIdx = 0;
                    showMentionPopup(query);
                } else if (mentionState.active) {
                    closeMentionPopup();
                }
            } else if (mentionState.active) {
                closeMentionPopup();
            }
        }
        if (activeChat && DOM.messageInput.value.trim().length > 0) {
            fetch(`/api/typing/${activeChat.type}/${activeChat.id}`, { method: 'POST' });
        }
    }

    async function handleMessageKeydown(e) {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); await sendMessage(); }
        if (e.key === 'Tab' && mentionState.active) { e.preventDefault(); completeMention(); }
        if (e.key === 'ArrowDown' && mentionState.active) {
            e.preventDefault();
            mentionState.selectedIdx = Math.min(mentionState.selectedIdx + 1, mentionState.users.length - 1);
            const popup = document.getElementById('mentionPopup');
            if (popup) { const items = popup.querySelectorAll('.mention-item'); items.forEach((el, i) => el.classList.toggle('selected', i === mentionState.selectedIdx)); }
        }
        if (e.key === 'ArrowUp' && mentionState.active) {
            e.preventDefault();
            mentionState.selectedIdx = Math.max(mentionState.selectedIdx - 1, 0);
            const popup = document.getElementById('mentionPopup');
            if (popup) { const items = popup.querySelectorAll('.mention-item'); items.forEach((el, i) => el.classList.toggle('selected', i === mentionState.selectedIdx)); }
        }
    }

    async function fetchTypingStatus() {
        if (!activeChat) return;
        try {
            const res = await fetch(`/api/typing/${activeChat.type}/${activeChat.id}`);
            const data = await res.json();
            const statusEl = getEl('chatHeaderStatus');
            if (statusEl && data.typing && data.typing.length > 0) {
                const names = data.typing.map(u => u.name).join(', ');
                statusEl.innerHTML = `${escapeHtml(names)} <span class="typing-indicator" style="display:inline-flex;vertical-align:middle;gap:2px;margin-left:4px"><span class="typing-dot" style="width:5px;height:5px;background:var(--accent-green);display:inline-block;border-radius:50%;animation:typingDot 1.4s infinite ease-in-out"></span><span class="typing-dot" style="width:5px;height:5px;background:var(--accent-green);display:inline-block;border-radius:50%;animation:typingDot 1.4s infinite ease-in-out;animation-delay:0.2s"></span><span class="typing-dot" style="width:5px;height:5px;background:var(--accent-green);display:inline-block;border-radius:50%;animation:typingDot 1.4s infinite ease-in-out;animation-delay:0.4s"></span></span>`;
                statusEl.classList.add('typing');
            } else {
                if (activeChat.type === 'personal' && activeChat.last_seen) statusEl.innerHTML = formatLastSeen(activeChat.last_seen);
                else if (activeChat.type !== 'personal') statusEl.innerHTML = '';
                statusEl.classList.remove('typing');
            }
        } catch (e) {}
    }

    // Stories
    async function loadStories() {
        if (!window.currentUserId) return;
        try {
            const r = await fetch('/api/stories'); const d = await r.json();
            if (d.success) { window.currentStories = d.stories || []; renderStoriesRow(); }
        } catch (e) {}
    }

    function renderStoriesRow() {
        const row = DOM.storiesRow; if (!row) return;
        const stories = window.currentStories || [];
        const hasStory = stories.some(s => s.user_id === window.currentUserId);
        let html = `<div class="story-item" onclick="showCreateStoryModal()">
            <div class="story-avatar ${hasStory ? '' : 'add-story'}">
                ${hasStory ? `<div class="story-avatar-placeholder" style="background:linear-gradient(135deg,#fb6340,#2dce89)">${window.currentUserAvatar}</div>` : `<div class="add-story-btn" style="background:linear-gradient(135deg,#fb6340,#2dce89);color:white">+</div>`}
            </div>
            <span class="story-username">Your story</span>
        </div>`;
        for (const s of stories) {
            if (s.user_id === window.currentUserId) continue;
            const f = s.stories[0];
            html += `<div class="story-item" onclick="openStoryViewer(${s.user_id})">
                <div class="story-avatar ${s.has_unviewed ? 'unviewed' : 'viewed'}">
                    ${f?.media_url && f.media_type==='image' ? `<img src="${f.media_url}" alt="${escapeHtml(s.display_name)}">` : `<div class="story-avatar-placeholder" style="background:linear-gradient(135deg,#fb6340,#2dce89)">${s.avatar_letter}</div>`}
                </div>
                <span class="story-username">${escapeHtml(s.display_name)}</span>
            </div>`;
        }
        row.innerHTML = html;
    }

    window.showCreateStoryModal = () => {
        const m = document.createElement('div'); m.className = 'modal-overlay';
        m.innerHTML = `
            <div class="modal-container" style="max-width:400px">
                <div class="modal-header" style="background:linear-gradient(135deg,#fb6340,#2dce89);color:white">
                    <h3>Create Story</h3><button class="modal-close" onclick="this.closest('.modal-overlay').remove()" style="color:white">✕</button>
                </div>
                <div class="modal-body">
                    <div class="story-media-upload" onclick="document.getElementById('storyMediaInput').click()">
                        <div class="upload-placeholder" id="storyMediaPreview"><span style="font-size:48px">📸</span><p>Click to upload</p></div>
                        <input type="file" id="storyMediaInput" accept="image/*,video/*" style="display:none" onchange="previewStoryMedia(this)">
                    </div>
                    <textarea id="storyCaption" class="modal-input" placeholder="Caption..." rows="2"></textarea>
                </div>
                <div class="modal-footer">
                    <button class="modal-btn modal-btn-secondary" onclick="this.closest('.modal-overlay').remove()">Cancel</button>
                    <button class="modal-btn modal-btn-primary" onclick="uploadStory()" style="background:linear-gradient(135deg,#fb6340,#2dce89)">Post</button>
                </div>
            </div>
        `;
        (DOM.modalRoot || document.body).appendChild(m);
    };

    window.previewStoryMedia = (i) => {
        const f = i.files[0]; if (!f) return; const p = getEl('storyMediaPreview'); if (!p) return;
        p.innerHTML = f.type.startsWith('video/') ? `<video src="${URL.createObjectURL(f)}" autoplay loop muted style="width:100%;height:100%;object-fit:cover"></video>` : `<img src="${URL.createObjectURL(f)}" style="width:100%;height:100%;object-fit:cover">`;
    };

    window.uploadStory = async () => {
        const f = getEl('storyMediaInput')?.files[0]; if (!f) { showToast('Select media', 'error'); return; }
        const fd = new FormData(); fd.append('media', f); fd.append('caption', getEl('storyCaption')?.value || '');
        try {
            const r = await fetch('/api/stories/create', { method: 'POST', body: fd }); const d = await r.json();
            if (d.success) {
                document.querySelectorAll('.modal-overlay').forEach(m => m.remove());
                showToast('Story posted!', 'success');
                await loadStories();
                setTimeout(() => {
                    const yourStory = document.querySelector('.story-item .story-avatar-placeholder');
                    yourStory?.scrollIntoView({ behavior: 'smooth' });
                }, 200);
            }
        } catch (e) {}
    };

    window.openStoryViewer = (uid) => {
        const u = window.currentStories.find(s => s.user_id === uid); if (!u) return;
        window.currentStoryUser = u; window.currentStoryIndex = 0; renderStoryViewer();
    };

    function renderStoryViewer() {
        const story = window.currentStoryUser?.stories?.[window.currentStoryIndex]; if (!story) return;
        const v = document.createElement('div'); v.className = 'story-viewer'; v.id = 'storyViewer';
        v.innerHTML = `
            <div class="story-viewer-header">
                <div class="story-progress-container">
                    ${window.currentStoryUser.stories.map((_, i) => `<div class="story-progress-bar-container"><div class="story-progress-bar ${i < window.currentStoryIndex ? 'completed' : ''}" id="storyProgress${i}" style="background:linear-gradient(90deg,#fb6340,#2dce89)"></div></div>`).join('')}
                </div>
                <div class="story-viewer-user">
                    <div class="story-viewer-avatar" style="background:linear-gradient(135deg,#fb6340,#2dce89)">${window.currentStoryUser.avatar_letter}</div>
                    <div class="story-viewer-info">
                        <span class="story-viewer-name" onclick="openUserProfileModalFromStory(${story.user_id})">${escapeHtml(window.currentStoryUser.display_name)}</span>
                        <span class="story-viewer-time">${formatTime(story.created_at)}</span>
                    </div>
                </div>
                <button class="story-viewer-close" onclick="closeStoryViewer()">✕</button>
            </div>
            <div class="story-viewer-content">
                ${story.media_type === 'video' ? `<video src="${story.media_url}" autoplay loop muted></video>` : `<img src="${story.media_url}" alt="story">`}
                ${story.caption ? `<div class="story-caption">${escapeHtml(story.caption)}</div>` : ''}
            </div>
            <div class="story-viewer-footer">
                <div class="story-reply-input">
                    <input type="text" id="storyReplyInput" placeholder="Reply...">
                    <button onclick="sendStoryReply()">➤</button>
                </div>
                <div class="story-actions">
                    <button onclick="likeCurrentStory()" id="storyLikeBtn">${story.liked ? '❤️' : '🤍'} <span>${story.like_count}</span></button>
                    ${story.user_id === window.currentUserId ? `<button onclick="deleteCurrentStory()">🗑️</button>` : ''}
                    <button onclick="showStoryStats()">👁️</button>
                    ${!story.user_id || story.user_id !== window.currentUserId ? `<div class="story-reactions">
                        <span class="story-reaction" onclick="reactToCurrentStory('❤️')">❤️</span>
                        <span class="story-reaction" onclick="reactToCurrentStory('🔥')">🔥</span>
                        <span class="story-reaction" onclick="reactToCurrentStory('👎')">👎</span>
                        <span class="story-reaction" onclick="reactToCurrentStory('👍')">👍</span>
                    </div>` : ''}
                </div>
            </div>
            <div class="story-nav">
                <div class="story-nav-left" onclick="previousStory()"></div>
                <div class="story-nav-right" onclick="nextStory()"></div>
            </div>
        `;
        document.body.appendChild(v); document.body.style.overflow = 'hidden';
        startProgress(); fetch(`/api/stories/${story.id}/view`, { method: 'POST' });
    }

    function startProgress() {
        if (window.storyProgressInterval) clearInterval(window.storyProgressInterval);
        const b = getEl(`storyProgress${window.currentStoryIndex}`); if (!b) return;
        let w = 0;
        window.storyProgressInterval = setInterval(() => {
            w += 1; b.style.width = w + '%';
            if (w >= 100) { clearInterval(window.storyProgressInterval); nextStory(); }
        }, 50);
    }

    window.nextStory = () => {
        if (window.currentStoryIndex < window.currentStoryUser.stories.length - 1) {
            window.currentStoryIndex++; getEl('storyViewer')?.remove(); renderStoryViewer();
        } else {
            const idx = window.currentStories.findIndex(s => s.user_id === window.currentStoryUser.user_id);
            if (idx < window.currentStories.length - 1) {
                window.currentStoryUser = window.currentStories[idx + 1]; window.currentStoryIndex = 0;
                getEl('storyViewer')?.remove(); renderStoryViewer();
            } else { closeStoryViewer(); }
        }
    };

    window.previousStory = () => {
        if (window.currentStoryIndex > 0) {
            window.currentStoryIndex--; getEl('storyViewer')?.remove(); renderStoryViewer();
        } else {
            const idx = window.currentStories.findIndex(s => s.user_id === window.currentStoryUser.user_id);
            if (idx > 0) {
                window.currentStoryUser = window.currentStories[idx - 1];
                window.currentStoryIndex = window.currentStoryUser.stories.length - 1;
                getEl('storyViewer')?.remove(); renderStoryViewer();
            }
        }
    };

    window.closeStoryViewer = () => {
        if (window.storyProgressInterval) clearInterval(window.storyProgressInterval);
        getEl('storyViewer')?.remove(); document.body.style.overflow = ''; loadStories();
    };

    window.likeCurrentStory = async () => {
        const s = window.currentStoryUser?.stories?.[window.currentStoryIndex]; if (!s) return;
        try { const r = await fetch(`/api/stories/${s.id}/like`, { method: 'POST' }); const d = await r.json();
            if (d.success) { s.liked = d.liked; s.like_count = d.like_count; const b = getEl('storyLikeBtn');
                if (b) b.innerHTML = `${d.liked ? '❤️' : '🤍'} <span>${d.like_count}</span>`; }
        } catch (e) {}
    };

    window.reactToCurrentStory = async (reaction) => {
        const s = window.currentStoryUser?.stories?.[window.currentStoryIndex]; if (!s) return;
        try { await fetch('/api/stories/' + s.id + '/reaction', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ reaction }) }); }
        catch (e) {}
    };

    window.deleteCurrentStory = async () => {
        if (!confirm('Delete?')) return; const s = window.currentStoryUser?.stories?.[window.currentStoryIndex]; if (!s) return;
        try { const r = await fetch(`/api/stories/${s.id}`, { method: 'DELETE' });
            if (r.ok) { closeStoryViewer(); loadStories(); }
        } catch (e) {}
    };

    window.sendStoryReply = () => {
        const m = getEl('storyReplyInput')?.value.trim(); if (!m) return;
        openChat('personal', window.currentStoryUser.user_id);
        setTimeout(() => { if (DOM.messageInput) { DOM.messageInput.value = m; DOM.sendBtn.disabled = false; } }, 500);
        closeStoryViewer();
    };

    window.showStoryStats = () => {
        const s = window.currentStoryUser?.stories?.[window.currentStoryIndex]; if (!s) return;
        fetch(`/api/stories/${s.id}/stats`).then(r => r.json()).then(stats => {
            let html = '<div style="max-height:300px;overflow-y:auto;">';
            html += `<p>👁️ Views: ${stats.total_views}</p><p>❤️ Likes: ${stats.total_likes}</p><p>😊 Reactions: ${stats.total_reactions}</p>`;
            if (stats.viewers) { html += '<p><strong>Viewers:</strong></p><ul>'; stats.viewers.forEach(v => html += `<li>${escapeHtml(v.display_name)}</li>`); html += '</ul>'; }
            html += '</div>';
            const modal = document.createElement('div'); modal.className = 'modal-overlay'; modal.style.display = 'flex';
            modal.innerHTML = `<div class="modal-container"><div class="modal-header"><h3>Story Stats</h3><button class="modal-close" onclick="this.closest('.modal-overlay').remove()">✕</button></div><div class="modal-body">${html}</div></div>`;
            document.body.appendChild(modal);
            modal.onclick = (e) => { if (e.target === modal) modal.remove(); };
        });
    };

    // Chat List (local time)
    async function loadChatList() {
        const c = DOM.chatList; if (!c) return;
        // Show skeleton while loading
        c.innerHTML = Array(5).fill('<div class="skeleton-chat-item"><div class="skeleton-avatar"></div><div class="skeleton-lines"><div class="skeleton-line medium"></div><div class="skeleton-line short"></div></div></div>').join('');
        try {
            const res = await fetch('/api/chat_list'); const data = await res.json();
            if (data.success) renderChatList(data.chats || []);
        } catch (e) { c.innerHTML = '<div class="empty-state"><p>Failed to load</p></div>'; }
    }

    function renderChatList(chats) {
        const c = DOM.chatList; if (!c) return;
        if (!chats?.length) {
            let savedMsg = '';
            if (window.currentUserId) {
                const active = activeChat?.type === 'saved' || false;
                savedMsg = `<div class="chat-item ${active?'active':''}" data-chat-type="saved" data-chat-id="${window.currentUserId}" onclick="openSavedMessages()">
                    <div class="chat-avatar saved"><span style="font-size:20px">📌</span></div>
                    <div class="chat-info">
                        <div class="chat-name-row"><span class="chat-name">Saved Messages</span></div>
                        <div class="chat-preview"><span>Your saved messages</span></div>
                    </div>
                </div>`;
            }
            c.innerHTML = savedMsg + `
                <div class="empty-state-detailed">
                    <svg class="empty-icon-svg" viewBox="0 0 120 120" fill="none">
                        <circle cx="60" cy="60" r="50" stroke="currentColor" stroke-width="2" stroke-dasharray="6 4" opacity="0.3"/>
                        <path d="M36 72 L60 84 L84 72" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity="0.4"/>
                        <circle cx="60" cy="52" r="16" stroke="currentColor" stroke-width="2" opacity="0.4"/>
                        <circle cx="60" cy="52" r="6" fill="currentColor" opacity="0.3"/>
                    </svg>
                    <h3>No chats yet</h3>
                    <p>Start a conversation or save messages to yourself.</p>
                    <button class="empty-btn" onclick="showAddContactModal()">New Chat</button>
                </div>`;
            return;
        }
        // Saved Messages: always first chat
        let savedHtml = '';
        if (window.currentUserId) {
            const active = activeChat?.type === 'saved' || false;
            savedHtml = `<div class="chat-item ${active?'active':''}" data-chat-type="saved" data-chat-id="${window.currentUserId}" onclick="openSavedMessages()">
                <div class="chat-avatar saved">
                    <span style="font-size:20px">📌</span>
                </div>
                <div class="chat-info">
                    <div class="chat-name-row"><span class="chat-name">Saved Messages</span></div>
                    <div class="chat-preview"><span>Your saved messages</span></div>
                </div>
            </div>`;
        }
        c.innerHTML = savedHtml + (chats || []).map(chat => {
            const active = activeChat?.type===chat.type && activeChat?.id===chat.id;
            let avatarHtml = '';
            if (chat.avatar_url) {
                avatarHtml = `<img src="${chat.avatar_url}" alt="${escapeHtml(chat.name)}">`;
            } else {
                avatarHtml = chat.avatar || '?';
            }
            // Truncate preview: show "Photo"/"Video"/"Voice Message"/"Document" instead of filenames
            let preview = chat.last_message || '';
            if (chat.last_message_type === 'image') preview = '📷 Photo';
            else if (chat.last_message_type === 'video') preview = '🎬 Video';
            else if (chat.last_message_type === 'audio' || chat.last_message_type === 'voice') preview = '🎤 Voice message';
            else if (chat.last_message_type === 'file') preview = '📎 Document';
            const muted = chat.is_muted;
            return `<div class="chat-item ${active?'active':''}" data-chat-type="${chat.type}" data-chat-id="${chat.id}" onclick="openChat('${chat.type}',${chat.id})">
                <div class="chat-avatar ${chat.type} ${chat.has_story?'has-story':''}">
                    ${avatarHtml}
                    ${chat.type==='personal'&&chat.is_online?'<span class="online-indicator"></span>':''}
                </div>
                <div class="chat-info">
                    <div class="chat-name-row"><span class="chat-name">${escapeHtml(chat.name)}</span><span class="chat-time">${formatChatTime(chat.timestamp)}</span></div>
                    <div class="chat-preview"><span>${escapeHtml(preview)}</span>${chat.unread_count>0?`<span class="unread-badge ${muted?'muted':''}">${chat.unread_count}</span>`:''}</div>
                </div>
            </div>`;
        }).join('');
    }

    function renderChatList(chats) {
        const c = DOM.chatList; if (!c) return;
        if (!chats?.length) { c.innerHTML = '<div class="empty-state"><div class="empty-icon">💬</div><p>No chats</p></div>'; return; }
        c.innerHTML = chats.map(chat => {
            const active = activeChat?.type===chat.type && activeChat?.id===chat.id;
            let avatarHtml = '';
            if (chat.avatar_url) {
                avatarHtml = `<img src="${chat.avatar_url}" alt="${escapeHtml(chat.name)}">`;
            } else {
                avatarHtml = chat.avatar || '?';
            }
            return `<div class="chat-item ${active?'active':''}" data-chat-type="${chat.type}" data-chat-id="${chat.id}" onclick="openChat('${chat.type}',${chat.id})">
                <div class="chat-avatar ${chat.type} ${chat.has_story?'has-story':''}">
                    ${avatarHtml}
                    ${chat.type==='personal'&&chat.is_online?'<span class="online-indicator"></span>':''}
                </div>
                <div class="chat-info">
                    <div class="chat-name-row"><span class="chat-name">${escapeHtml(chat.name)}</span><span class="chat-time">${formatChatTime(chat.timestamp)}</span></div>
                    <div class="chat-preview"><span>${escapeHtml(chat.last_message||'')}</span>${chat.unread_count>0?`<span class="unread-badge">${chat.unread_count}</span>`:''}</div>
                </div>
            </div>`;
        }).join('');
    }

    // Messages (local time in bubbles)
    async function refreshMessages() {
        if (!activeChat) return;
        let url;
        if (activeChat.type === 'personal') url = `/api/messages/${activeChat.id}`;
        else if (activeChat.type === 'group') url = `/api/group_messages/${activeChat.id}`;
        else if (activeChat.type === 'channel') url = `/api/channel_messages/${activeChat.id}`;
        else return;
        const res = await fetch(`${url}?after=0&limit=50`); const data = await res.json();
        const msgs = data.messages || (data.success && data.messages) || [];
        const newHash = msgs.map(m => `${m.id}:${m.content}:${m.is_read}`).join('|');
        const cacheKey = `${activeChat.type}_${activeChat.id}`;
        if (newHash !== cachedMessages.get(cacheKey)) {
            cachedMessages.set(cacheKey, newHash); renderMessages(msgs); applyWallpaper();
        }
    }

    function renderMessages(msgs) {
        const c = DOM.messagesContainer; if (!c) return;
        let h = '', lastDate = null, lastSender = null, lastTime = null, isGrouped = false;

        const isConsecutive = (m, prevSender, prevTime) => {
            if (m.sender_id !== prevSender) return false;
            if (!prevTime) return false;
            const diff = new Date(m.timestamp) - new Date(prevTime);
            return diff < 300000; // 5 min
        };

        for (const m of msgs) {
            const d = new Date(m.timestamp || Date.now()); const ds = d.toLocaleDateString();
            if (ds !== lastDate) {
                lastDate = ds;
                const today = new Date(), yesterday = new Date(today); yesterday.setDate(yesterday.getDate()-1);
                let label = d.toLocaleDateString(undefined, { month:'long', day:'numeric' });
                if (ds === today.toLocaleDateString()) label = 'Today';
                else if (ds === yesterday.toLocaleDateString()) label = 'Yesterday';
                h += `<div class="message-date-divider"><span>${label}</span></div>`;
                lastSender = null; lastTime = null; isGrouped = false;
            }

            const isOwn = m.is_own || m.sender_id === window.currentUserId;
            const consecutive = isConsecutive(m, lastSender, lastTime);

            // Collect all image URLs for lightbox gallery
            const allImages = msgs.filter(x => x.has_attachment && x.file_type === 'image' && x.file_url).map(x => x.file_url);

            h += renderMessage(m, consecutive, allImages);

            lastSender = m.sender_id;
            lastTime = m.timestamp;
        }
        c.innerHTML = h || '<div class="empty-state"><p>No messages</p></div>';
        c.scrollTop = c.scrollHeight;
        // Re-apply emoji picker content
        renderEmojiPicker();
    }

    function renderMessage(m, consecutive = false) {
        const isOwn = m.is_own || m.sender_id === window.currentUserId;
        const msgTime = m.timestamp ? new Date(m.timestamp).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) : '';

        // Read receipt status
        let readStatus = '';
        if (isOwn) {
            if (m.is_read) readStatus = `<span class="read-receipt read" title="Read">✓✓</span>`;
            else readStatus = `<span class="read-receipt" title="Delivered">✓✓</span>`;
        }

        let att = '';
        if (m.has_attachment) {
            const ps = m.preview_size || 'medium';
            const ext = (m.file_name || '').split('.').pop().toLowerCase();
            const imgExts = ['jpg','jpeg','png','gif','webp','bmp','svg'];
            const vidExts = ['mp4','webm','avi','mov','mkv','flv','m4v'];
            const isImg = m.file_type === 'image' || imgExts.includes(ext);
            const isVid = m.file_type === 'video' || vidExts.includes(ext);
            if (ps === 'none') {
                let icon = 'fa-file';
                if (ext === 'pdf') icon = 'fa-file-pdf';
                else if (['doc','docx'].includes(ext)) icon = 'fa-file-word';
                else if (['xls','xlsx'].includes(ext)) icon = 'fa-file-excel';
                else if (['zip','rar','7z'].includes(ext)) icon = 'fa-file-archive';
                else if (ext === 'txt' || ext === 'text') icon = 'fa-file-alt';
                else if (m.file_type === 'image') icon = 'fa-file-image';
                else if (m.file_type === 'video') icon = 'fa-file-video';
                else if (m.file_type === 'audio' || m.file_type === 'voice') icon = 'fa-file-audio';
                const size = m.formatted_size || (m.file_size ? formatFileSize(m.file_size) : '');
                att = `<div class="file-attachment"><i class="fas ${icon}"></i><div class="file-attach-info"><a href="${m.file_url}" target="_blank" class="file-link">${escapeHtml(m.file_name || 'File')}</a>${size ? `<span class="file-size">${size}</span>` : ''}</div></div>`;
            } else if (isImg) {
                const cls = ps === 'big' ? 'message-image big-preview' : 'message-image';
                att = `<img src="${m.file_url}" class="${cls}" onclick="openImageViewer('${m.file_url}')">`;
            } else if (isVid) {
                att = `<video src="${m.file_url}" controls preload="metadata" style="max-width:100%;max-height:300px;border-radius:12px;margin-bottom:4px"></video>`;
            } else if (m.file_type === 'audio' || m.file_type === 'voice') {
                att = `<audio src="${m.file_url}" controls style="max-width:220px;height:40px;border-radius:8px;display:block;margin-bottom:4px"></audio>`;
            } else {
                att = `<div class="file-attachment"><i class="fas fa-file"></i><a href="${m.file_url}" target="_blank">${escapeHtml(m.file_name || 'File')}</a></div>`;
            }
        }
        let reply = '';
        if (m.reply_to_id) {
            reply = `<div class="reply-indicator"><span>↩️ Reply</span><div style="font-size:11px">${escapeHtml(m.reply_to_content||'')}</div></div>`;
        }

        const groupClass = consecutive ? ' grouped' : '';

        // Hover actions: Reply, Forward, Copy
        const hoverActions = `
            <div class="message-hover-actions">
                <button class="message-hover-btn" onclick="event.stopPropagation();setReply(${m.id})" title="Reply">↩️</button>
                <button class="message-hover-btn" onclick="event.stopPropagation();forwardMessage(${m.id})" title="Forward">➡️</button>
                <button class="message-hover-btn" onclick="event.stopPropagation();copyMessage(${m.id})" title="Copy">📋</button>
            </div>`;

        return `<div class="message-wrapper ${isOwn?'outgoing':'incoming'}${groupClass}" id="msg-${m.id}" ${isOwn ? '' : ''}>
            <div class="message-checkbox" onclick="event.stopPropagation();toggleMessageSelection('${m.id}')"></div>
            ${(!isOwn && !consecutive) ? `<div class="message-sender">${escapeHtml(m.sender_name||'User')}</div>` : ''}
            <div class="message-bubble" ondblclick="enterSelectionMode('${m.id}')">
                ${reply}
                ${att}
                ${m.content ? `<div class="message-text">${escapeHtml(m.content).replace(/\n/g,'<br>')}</div>` : ''}
                <div class="message-meta">
                    <span class="message-time">${msgTime}</span>
                    ${readStatus}
                </div>
            </div>
            ${hoverActions}
        </div>`;
    }

    function applyWallpaper() {
        if (!activeChat) return; const c = DOM.messagesContainer; if (!c) return;
        const w = localStorage.getItem(`wallpaper_${activeChat.type}_${activeChat.id}`) || 'default';
        c.classList.remove('wallpaper-gradient1','wallpaper-gradient2','wallpaper-gradient3','wallpaper-gradient4','wallpaper-gradient5');
        if (w !== 'default') c.classList.add(`wallpaper-${w}`);
    }

    async function sendMessage() {
        const content = DOM.messageInput?.value.trim();
        if (!content || !activeChat) return;
        const payload = { content };
        let url;
        if (activeChat.type === 'personal') { url = '/api/send_message'; payload.receiver_id = activeChat.id; }
        else if (activeChat.type === 'group') { url = '/api/send_group_message'; payload.group_id = activeChat.id; }
        else if (activeChat.type === 'channel') { url = '/api/send_channel_message'; payload.channel_id = activeChat.id; }
        if (replyToMessage) { payload.reply_to_id = replyToMessage; replyToMessage = null; if (DOM.replyPreview) DOM.replyPreview.style.display = 'none'; }
        const tempId = 'temp_' + Date.now() + Math.random();
        const optimisticMsg = { id: tempId, content, sender_id: window.currentUserId, sender_name: window.currentUserDisplayName, timestamp: new Date().toISOString(), timestamp_formatted: new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}), is_own: true, is_read: false, has_attachment: false, reactions: {} };
        const container = DOM.messagesContainer;
        if (container) {
            if (container.querySelector('.empty-state')) container.innerHTML = '';
            container.insertAdjacentHTML('beforeend', renderMessage(optimisticMsg)); container.scrollTop = container.scrollHeight;
        }
        DOM.messageInput.value = ''; handleMessageInput();
        if (!isOnline) {
            offlineQueue.push({...payload, temp_id: tempId, target_type: activeChat.type, target_id: activeChat.id});
            showToast('Message queued for offline', 'info'); return;
        }
        try {
            const r = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
            const d = await r.json();
            if (d.success && d.message) {
                const tempEl = document.getElementById(`msg-${tempId}`); if (tempEl) tempEl.outerHTML = renderMessage(d.message);
                loadChatList();
            } else { document.getElementById(`msg-${tempId}`)?.remove(); showToast('Failed to send', 'error'); }
        } catch (e) { document.getElementById(`msg-${tempId}`)?.remove(); offlineQueue.push({...payload, temp_id: tempId, target_type: activeChat.type, target_id: activeChat.id}); showToast('Offline – message queued', 'info'); }
    }

    window.openSavedMessages = async () => {
        const id = window.currentUserId;
        if (!id) return;
        activeChat = { type: 'personal', id, is_saved: true };
        document.querySelectorAll('.chat-item').forEach(i => i.classList.remove('active'));
        document.querySelector(`.chat-item[data-chat-type="saved"]`)?.classList.add('active');
        hideAllPanels(); if (DOM.chatView) DOM.chatView.style.display = 'flex';
        if (DOM.chatHeaderName) DOM.chatHeaderName.textContent = 'Saved Messages';
        if (DOM.chatHeaderStatus) { DOM.chatHeaderStatus.textContent = 'Your notes & bookmarks'; DOM.chatHeaderStatus.classList.remove('online'); }
        if (DOM.chatHeaderAvatar) { DOM.chatHeaderAvatar.innerHTML = '📌'; DOM.chatHeaderAvatar.className = 'chat-header-avatar saved'; }
        await loadMessages('personal', id, true);
        // Restore header after loadChatInfo overwrites it
        if (DOM.chatHeaderName) DOM.chatHeaderName.textContent = 'Saved Messages';
        if (DOM.chatHeaderStatus) DOM.chatHeaderStatus.textContent = 'Your notes & bookmarks';
        if (DOM.chatHeaderAvatar) { DOM.chatHeaderAvatar.innerHTML = '📌'; DOM.chatHeaderAvatar.className = 'chat-header-avatar saved'; }
        DOM.messageInput?.focus();
        exitSelectionMode();
    };

    window.openChat = async (type, id) => {
        activeChat = { type, id };
        document.querySelectorAll('.chat-item').forEach(i => i.classList.remove('active'));
        document.querySelector(`.chat-item[data-chat-type="${type}"][data-chat-id="${id}"]`)?.classList.add('active');
        hideAllPanels(); if (DOM.chatView) DOM.chatView.style.display = 'flex';
        await loadChatInfo(type, id); await loadMessages(type, id, true); applyWallpaper();
        if (type === 'personal') await fetch(`/api/mark_read/${id}`, { method: 'POST' });
        DOM.messageInput?.focus();
        // Clear chat search
        const searchBar = document.querySelector('.chat-search-bar');
        if (searchBar) { searchBar.classList.remove('active'); searchBar.querySelector('.chat-search-input').value = ''; }
        chatSearchResults = []; chatSearchIndex = -1;
        clearChatSearchHighlights();
        // Exit selection mode
        exitSelectionMode();
    };

    async function loadChatInfo(type, id) {
        if (type === 'personal') {
            try {
                const r = await fetch('/api/users'); const d = await r.json(); const u = d.users?.find(u => u.id === id);
                if (u) {
                    if (DOM.chatHeaderName) DOM.chatHeaderName.textContent = u.display_name || u.username;
                    if (DOM.chatHeaderStatus) { DOM.chatHeaderStatus.textContent = u.is_online ? 'Online' : 'Offline'; DOM.chatHeaderStatus.classList.toggle('online', u.is_online); }
                    if (DOM.chatHeaderAvatar) { DOM.chatHeaderAvatar.innerHTML = u.avatar_url ? `<img src="${u.avatar_url}">` : u.username[0].toUpperCase(); DOM.chatHeaderAvatar.className = 'chat-header-avatar personal'; }
                    activeChat.last_seen = u.last_seen;
                }
            } catch (e) {}
        } else if (type === 'group') {
            const r = await fetch(`/api/groups/${id}`); const d = await r.json();
            if (d.success && d.group) {
                if (DOM.chatHeaderName) DOM.chatHeaderName.textContent = d.group.name;
                if (DOM.chatHeaderStatus) DOM.chatHeaderStatus.textContent = `${d.group.member_count || 0} participants`;
                if (DOM.chatHeaderAvatar) { DOM.chatHeaderAvatar.innerHTML = d.group.avatar_url ? `<img src="${d.group.avatar_url}">` : '👥'; DOM.chatHeaderAvatar.className = 'chat-header-avatar group'; }
            }
        } else if (type === 'channel') {
            const r = await fetch(`/api/channels/${id}`); const d = await r.json();
            if (d.success && d.channel) {
                if (DOM.chatHeaderName) DOM.chatHeaderName.textContent = d.channel.name;
                if (DOM.chatHeaderStatus) DOM.chatHeaderStatus.textContent = `${d.channel.subscriber_count || 0} subscribers`;
                if (DOM.chatHeaderAvatar) { DOM.chatHeaderAvatar.innerHTML = d.channel.avatar_url ? `<img src="${d.channel.avatar_url}">` : '📢'; DOM.chatHeaderAvatar.className = 'chat-header-avatar channel'; }
            }
        }
    }

    function hideAllPanels() { [DOM.emptyChat, DOM.chatView, DOM.contactsView, DOM.createGroupView, DOM.createChannelView].forEach(el => { if (el) el.style.display = 'none'; }); }

    async function loadMessages(type, id, forceRender = false) {
        const container = DOM.messagesContainer; if (!container) return;
        if (forceRender) container.innerHTML = '<div class="loading-spinner"></div>';
        try {
            let url;
            if (type === 'personal') url = `/api/messages/${id}`; else if (type === 'group') url = `/api/group_messages/${id}`;
            else if (type === 'channel') url = `/api/channel_messages/${id}`;
            const res = await fetch(`${url}?after=0&limit=50`); const data = await res.json();
            const msgs = data.messages || (data.success && data.messages) || [];
            cachedMessages.set(`${type}_${id}`, msgs.map(m => `${m.id}:${m.content}:${m.is_read}`).join('|'));
            renderMessages(msgs);
            if (forceRender) applyWallpaper();
        } catch (e) { if (forceRender) container.innerHTML = '<div class="empty-state"><p>Error</p></div>'; }
    }

    // Chat Customization (Premium)
    window.openChatCustomization = () => {
        const m = document.createElement('div'); m.className = 'modal-overlay';
        m.innerHTML = `
            <div class="modal-container" style="max-width:450px">
                <div class="modal-header" style="background:linear-gradient(135deg,#fb6340,#2dce89);color:white"><h3>Customization</h3><button class="modal-close" onclick="this.closest('.modal-overlay').remove()" style="color:white">✕</button></div>
                <div class="modal-body">
                    <h4>Wallpaper</h4>
                    <div class="wallpaper-options" style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
                        ${['gradient1','gradient2','gradient3','gradient4','gradient5','default'].map(w => `<div style="aspect-ratio:1;border-radius:8px;border:2px solid var(--border-color);cursor:pointer;background:${w==='default'?'var(--bg-surface)':''}" onclick="setWallpaper('${w}')">${w==='default'?'Default':''}</div>`).join('')}
                    </div>
                    <h4 style="margin-top:20px">Text Size</h4>
                    <div style="display:flex;gap:8px"><button class="modal-btn modal-btn-secondary" onclick="setTextSize('small')">Small</button><button class="modal-btn modal-btn-secondary" onclick="setTextSize('medium')">Medium</button><button class="modal-btn modal-btn-secondary" onclick="setTextSize('large')">Large</button></div>
                </div>
                <div class="modal-footer">
                    <button class="modal-btn modal-btn-secondary" onclick="resetChatCustomization()">Reset</button>
                    <button class="modal-btn modal-btn-primary" onclick="this.closest('.modal-overlay').remove()" style="background:linear-gradient(135deg,#fb6340,#2dce89)">Done</button>
                </div>
            </div>
        `;
        (DOM.modalRoot || document.body).appendChild(m);
    };
    window.setWallpaper = (w) => { if (!activeChat) return; localStorage.setItem(`wallpaper_${activeChat.type}_${activeChat.id}`, w); applyWallpaper(); showToast('Wallpaper updated', 'success'); };
    window.setTextSize = (size) => { const c = DOM.messagesContainer; if (c) { c.classList.remove('text-small','text-medium','text-large'); c.classList.add(`text-${size}`); localStorage.setItem('chat_text_size', size); } showToast('Text size updated', 'success'); };
    window.resetChatCustomization = () => { if (!activeChat) return; localStorage.removeItem(`wallpaper_${activeChat.type}_${activeChat.id}`); localStorage.removeItem('chat_text_size'); const c = DOM.messagesContainer; if (c) { c.classList.remove('wallpaper-gradient1','wallpaper-gradient2','wallpaper-gradient3','wallpaper-gradient4','wallpaper-gradient5','text-small','text-medium','text-large'); c.classList.add('text-medium'); } showToast('Reset', 'success'); };

    // Settings / Theme / Font
    function togglePopoutMenu() { document.body.classList.toggle('popout-open'); getEl('menuBtn')?.classList.toggle('active'); }
    window.closePopout = () => { document.body.classList.remove('popout-open'); getEl('menuBtn')?.classList.remove('active'); };
    window.closeAllPanels = () => { getEl('settingsPanel')?.classList.remove('open'); getEl('privacyPanel')?.classList.remove('open'); getEl('panelOverlay')?.classList.remove('visible'); };
    window.openSettingsPanel = () => { window.closeAllPanels(); getEl('settingsPanel')?.classList.add('open'); getEl('panelOverlay')?.classList.add('visible'); window.closePopout(); };
    window.closeSettingsPanel = () => { getEl('settingsPanel')?.classList.remove('open'); getEl('panelOverlay')?.classList.remove('visible'); };
    window.openPrivacyPanel = () => { window.closeAllPanels(); getEl('privacyPanel')?.classList.add('open'); getEl('panelOverlay')?.classList.add('visible'); window.closePopout(); };
    window.closePrivacyPanel = () => { getEl('privacyPanel')?.classList.remove('open'); getEl('panelOverlay')?.classList.remove('visible'); };
    window.setTheme = (theme) => { document.querySelectorAll('.theme-option').forEach(o => o.classList.remove('active')); if (event?.currentTarget) event.currentTarget.classList.add('active'); if (theme === 'dark') document.documentElement.setAttribute('data-theme', 'dark'); else if (theme === 'light') document.documentElement.setAttribute('data-theme', 'light'); else document.documentElement.removeAttribute('data-theme'); localStorage.setItem('kiselgram_theme', theme); };
    function loadThemePreference() {
        const t = localStorage.getItem('kiselgram_theme');
        if (t === 'auto' || !t) {
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            document.documentElement.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
            window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
                if (localStorage.getItem('kiselgram_theme') === 'auto' || !localStorage.getItem('kiselgram_theme')) {
                    document.documentElement.setAttribute('data-theme', e.matches ? 'dark' : 'light');
                }
            });
        } else if (t === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
        } else {
            document.documentElement.setAttribute('data-theme', 'light');
        }
    }
    window.setFont = (el) => { document.querySelectorAll('.font-option').forEach(o => o.classList.remove('active')); el.classList.add('active'); document.body.style.setProperty('--font-family', el.dataset.font); localStorage.setItem('kiselgram_font', el.dataset.font); showToast('Font updated', 'success'); };
    function loadFontPreference() { const f = localStorage.getItem('kiselgram_font'); if (f) document.body.style.setProperty('--font-family', f); }

    // Reply / Forward / Reactions
    window.setReply = (id) => { replyToMessage = id; const msg = getEl(`msg-${id}`); if (msg && DOM.replyPreview) { const t = msg.querySelector('.message-text')?.textContent || ''; DOM.replyPreview.querySelector('.reply-preview-name').textContent = 'Replying'; DOM.replyPreview.querySelector('.reply-preview-text').textContent = t.substring(0,50); DOM.replyPreview.style.display = 'flex'; } };
    window.cancelReply = () => { replyToMessage = null; if (DOM.replyPreview) DOM.replyPreview.style.display = 'none'; };
    window.deleteMessage = async (id) => { if (!confirm('Delete?')) return; try { await fetch(`/api/messages/${id}`, { method:'DELETE' }); getEl(`msg-${id}`)?.remove(); } catch (e) {} };
    // ===== FEATURE 1: IMAGE LIGHTBOX =====
    window.openImageViewer = (url) => {
        const existing = document.querySelector('.lightbox-overlay');
        if (existing) existing.remove();
        // Collect all images from current messages container
        const container = DOM.messagesContainer;
        const images = container ? Array.from(container.querySelectorAll('.message-image')).map(img => img.src) : [url];
        let idx = images.indexOf(url);
        if (idx === -1) idx = 0;
        const render = () => {
            const overlay = document.createElement('div'); overlay.className = 'lightbox-overlay';
            overlay.innerHTML = `
                <button class="lightbox-close" onclick="this.closest('.lightbox-overlay').remove()">✕</button>
                ${images.length > 1 ? `<button class="lightbox-nav lightbox-prev">‹</button><button class="lightbox-nav lightbox-next">›</button>` : ''}
                <img src="${images[idx]}" alt="image">
            `;
            document.body.appendChild(overlay);
            overlay.querySelector('.lightbox-prev')?.addEventListener('click', (e) => { e.stopPropagation(); idx = (idx - 1 + images.length) % images.length; overlay.remove(); render(); });
            overlay.querySelector('.lightbox-next')?.addEventListener('click', (e) => { e.stopPropagation(); idx = (idx + 1) % images.length; overlay.remove(); render(); });
            overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
            document.addEventListener('keydown', function lbKey(e) {
                if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', lbKey); }
                if (e.key === 'ArrowLeft') { idx = (idx - 1 + images.length) % images.length; overlay.remove(); render(); document.removeEventListener('keydown', lbKey); }
                if (e.key === 'ArrowRight') { idx = (idx + 1) % images.length; overlay.remove(); render(); document.removeEventListener('keydown', lbKey); }
            });
        };
        render();
    };

    // ===== FEATURE 2: MESSAGE GROUPING (in renderMessages) =====
    // Grouping is handled in renderMessages below — see the updated function.

    // ===== FEATURE 3: VOICE MESSAGE RECORDER =====
    let mediaRecorder = null;
    let audioChunks = [];
    let recordingTimer = null;
    let recordingSeconds = 0;

    window.toggleVoiceRecorder = () => {
        const bar = document.querySelector('.voice-recorder-bar');
        if (!bar) {
            showToast('Voice recorder not available', 'error');
            return;
        }
        if (bar.classList.contains('active')) {
            stopRecording();
            return;
        }
        startRecording();
    };

    async function startRecording() {
        if (!navigator.mediaDevices?.getUserMedia) {
            showToast('Voice recording not supported', 'error');
            return;
        }
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorder = new MediaRecorder(stream, { mimeType: MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/mp4' });
            audioChunks = [];
            recordingSeconds = 0;
            mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) audioChunks.push(e.data); };
            mediaRecorder.onstop = () => {
                stream.getTracks().forEach(t => t.stop());
                clearInterval(recordingTimer);
                document.querySelector('.voice-recorder-bar')?.classList.remove('active');
            };
            mediaRecorder.start();
            const bar = document.querySelector('.voice-recorder-bar');
            if (bar) {
                bar.classList.add('active');
                const timer = bar.querySelector('.voice-timer');
                const waveform = bar.querySelector('.voice-waveform');
                if (waveform) {
                    waveform.innerHTML = '';
                    for (let i = 0; i < 20; i++) {
                        const barEl = document.createElement('div');
                        barEl.className = 'bar';
                        barEl.style.animationDelay = `${i * 0.05}s`;
                        barEl.style.height = `${4 + Math.random() * 24}px`;
                        waveform.appendChild(barEl);
                    }
                }
                recordingTimer = setInterval(() => {
                    recordingSeconds++;
                    if (timer) timer.textContent = `${Math.floor(recordingSeconds / 60)}:${String(recordingSeconds % 60).padStart(2, '0')}`;
                }, 1000);
            }
        } catch (e) {
            showToast('Microphone access denied', 'error');
        }
    }

    window.stopRecording = () => {
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
        }
    };

    window.cancelRecording = () => {
        audioChunks = [];
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
        }
        document.querySelector('.voice-recorder-bar')?.classList.remove('active');
        clearInterval(recordingTimer);
    };

    window.sendVoiceMessage = async () => {
        if (audioChunks.length === 0) return;
        const blob = new Blob(audioChunks, { type: mediaRecorder?.mimeType || 'audio/webm' });
        audioChunks = [];
        document.querySelector('.voice-recorder-bar')?.classList.remove('active');
        clearInterval(recordingTimer);
        if (!activeChat) return;
        const fd = new FormData();
        fd.append('file', blob, `voice_${Date.now()}.webm`);
        if (activeChat.type === 'personal') fd.append('receiver_id', activeChat.id);
        else fd.append('group_id', activeChat.id);
        try {
            const r = await fetch('/files/upload_file', { method: 'POST', body: fd });
            const d = await r.json();
            if (d.success && DOM.messagesContainer) {
                if (DOM.messagesContainer.querySelector('.empty-state')) DOM.messagesContainer.innerHTML = '';
                DOM.messagesContainer.insertAdjacentHTML('beforeend', renderMessage(d.message));
                DOM.messagesContainer.scrollTop = DOM.messagesContainer.scrollHeight;
                loadChatList();
                showToast('Voice sent', 'success');
            }
        } catch (e) { showToast('Failed to send voice', 'error'); }
    };

    // ===== FEATURE 4: EMOJI PICKER =====
    window.toggleEmojiPicker = () => {
        const picker = document.querySelector('.emoji-picker');
        if (!picker) return;
        picker.classList.toggle('active');
    };

    window.insertEmoji = (emoji) => {
        const input = DOM.messageInput;
        if (!input) return;
        const start = input.selectionStart;
        const end = input.selectionEnd;
        input.value = input.value.substring(0, start) + emoji + input.value.substring(end);
        input.selectionStart = input.selectionEnd = start + emoji.length;
        input.focus();
        handleMessageInput();
        document.querySelector('.emoji-picker')?.classList.remove('active');
    };

    const EMOJI_CATEGORIES = {
        '😊': ['😊','😂','😍','🥰','😎','🤩','😢','😡','🥳','😇','🤗','🤔','🙄','😴','🥺','😰','🤒','🤕'],
        '👍': ['👍','👎','👏','🙌','🤝','💪','✌️','🤞','👀','💅','🫶','🤙','👋','🖐️','✋'],
        '❤️': ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','💔','💖','💝','✨','🔥','⭐','💯'],
        '🎉': ['🎉','🎊','🎈','🎁','🎂','🎶','🎵','💃','🕺','🎤','🎧','🎸','🎹','🎨','🏆'],
        '🐱': ['🐱','🐶','🐰','🦊','🐻','🐼','🐨','🐸','🐧','🐦','🐤','🦄','🐴','🐝','🐞'],
        '🍕': ['🍕','🍔','🌮','🍣','🍩','🍪','🍫','🍭','🍺','🍷','☕','🥤','🧊','🍰','🥗'],
    };

    function renderEmojiPicker() {
        const picker = document.querySelector('.emoji-picker');
        if (!picker) return;
        let catsHtml = '';
        let gridsHtml = '';
        Object.entries(EMOJI_CATEGORIES).forEach(([cat, emojis], ci) => {
            catsHtml += `<button class="emoji-cat ${ci === 0 ? 'active' : ''}" data-cat="${ci}" onclick="switchEmojiCat(${ci})">${cat}</button>`;
            gridsHtml += `<div class="emoji-grid" data-cat="${ci}" style="${ci === 0 ? '' : 'display:none'}">${emojis.map(e => `<button onclick="insertEmoji('${e}')">${e}</button>`).join('')}</div>`;
        });
        picker.innerHTML = `<div class="emoji-categories">${catsHtml}</div>${gridsHtml}`;
    }

    window.switchEmojiCat = (idx) => {
        document.querySelectorAll('.emoji-cat').forEach((c, i) => c.classList.toggle('active', i === idx));
        document.querySelectorAll('.emoji-grid').forEach((g, i) => g.style.display = i === idx ? 'grid' : 'none');
    };

    // ===== FEATURE 5: MESSAGE SELECTION MODE =====
    let selectedMessageIds = new Set();

    window.toggleMessageSelection = (id) => {
        if (selectedMessageIds.has(id)) {
            selectedMessageIds.delete(id);
        } else {
            selectedMessageIds.add(id);
        }
        updateSelectionUI();
    };

    window.enterSelectionMode = (id) => {
        document.body.classList.add('selection-mode');
        selectedMessageIds.add(id);
        updateSelectionUI();
        showToast('Select messages', 'info');
    };

    window.exitSelectionMode = () => {
        document.body.classList.remove('selection-mode');
        selectedMessageIds.clear();
        const bar = document.querySelector('.selection-bar');
        if (bar) bar.classList.remove('active');
        document.querySelectorAll('.message-checkbox').forEach(cb => cb.remove());
    };

    function updateSelectionUI() {
        const count = selectedMessageIds.size;
        const bar = document.querySelector('.selection-bar');
        const countEl = document.querySelector('.selection-count');
        if (bar && countEl) {
            bar.classList.toggle('active', count > 0);
            countEl.textContent = `${count} selected`;
        }
        document.querySelectorAll('.message-wrapper').forEach(w => {
            const id = w.id.replace('msg-', '');
            const cb = w.querySelector('.message-checkbox');
            if (cb) cb.classList.toggle('checked', selectedMessageIds.has(id));
        });
        if (count === 0) {
            document.body.classList.remove('selection-mode');
        }
    }

    window.deleteSelectedMessages = async () => {
        if (selectedMessageIds.size === 0) return;
        if (!confirm(`Delete ${selectedMessageIds.size} messages?`)) return;
        for (const id of selectedMessageIds) {
            try {
                await fetch(`/api/messages/${id}`, { method: 'DELETE' });
                document.getElementById(`msg-${id}`)?.remove();
            } catch (e) {}
        }
        selectedMessageIds.clear();
        updateSelectionUI();
        showToast('Deleted', 'success');
    };

    window.forwardSelectedMessages = () => {
        if (selectedMessageIds.size === 0) return;
        showToast(`Forward ${selectedMessageIds.size} message(s) — pick a chat`, 'info');
    };

    // ===== FEATURE 9: CHAT MESSAGE SEARCH =====
    let chatSearchResults = [];
    let chatSearchIndex = -1;

    window.toggleChatSearch = () => {
        const bar = document.querySelector('.chat-search-bar');
        if (bar) {
            bar.classList.toggle('active');
            if (bar.classList.contains('active')) {
                bar.querySelector('.chat-search-input')?.focus();
            } else {
                clearChatSearchHighlights();
            }
        }
    };

    async function handleChatSearchInput() {
        const input = document.querySelector('.chat-search-input');
        const q = input?.value.trim();
        const countEl = document.querySelector('.chat-search-count');
        if (!q || q.length < 2 || !activeChat) {
            chatSearchResults = [];
            chatSearchIndex = -1;
            if (countEl) countEl.textContent = '';
            clearChatSearchHighlights();
            return;
        }
        try {
            const res = await fetch('/api/search_in_chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ chat_id: activeChat.id, chat_type: activeChat.type, query: q })
            });
            const data = await res.json();
            chatSearchResults = data.messages || [];
            chatSearchIndex = chatSearchResults.length > 0 ? 0 : -1;
            highlightChatSearchResults(q);
            if (countEl) countEl.textContent = chatSearchResults.length > 0 ? `${chatSearchIndex + 1}/${chatSearchResults.length}` : 'No results';
            scrollToChatSearchResult();
        } catch (e) {}
    }

    function highlightChatSearchResults(query) {
        clearChatSearchHighlights();
        if (!query) return;
        document.querySelectorAll('.message-text').forEach(el => {
            if (el.textContent.toLowerCase().includes(query.toLowerCase())) {
                const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
                el.innerHTML = el.textContent.replace(regex, '<mark class="search-highlight">$1</mark>');
            }
        });
    }

    function clearChatSearchHighlights() {
        document.querySelectorAll('.message-text mark.search-highlight').forEach(m => {
            m.parentNode.replaceChild(document.createTextNode(m.textContent), m);
            m.parentNode.normalize();
        });
    }

    function scrollToChatSearchResult() {
        if (chatSearchIndex < 0 || chatSearchIndex >= chatSearchResults.length) return;
        const msgId = chatSearchResults[chatSearchIndex].id;
        const el = document.getElementById(`msg-${msgId}`);
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            el.style.transition = 'background 0.5s';
            el.style.background = 'rgba(255,213,0,0.15)';
            setTimeout(() => { el.style.background = ''; }, 2000);
        }
    }

    window.chatSearchPrev = () => {
        if (chatSearchResults.length === 0) return;
        chatSearchIndex = (chatSearchIndex - 1 + chatSearchResults.length) % chatSearchResults.length;
        const countEl = document.querySelector('.chat-search-count');
        if (countEl) countEl.textContent = `${chatSearchIndex + 1}/${chatSearchResults.length}`;
        scrollToChatSearchResult();
    };

    window.chatSearchNext = () => {
        if (chatSearchResults.length === 0) return;
        chatSearchIndex = (chatSearchIndex + 1) % chatSearchResults.length;
        const countEl = document.querySelector('.chat-search-count');
        if (countEl) countEl.textContent = `${chatSearchIndex + 1}/${chatSearchResults.length}`;
        scrollToChatSearchResult();
    };

    window.showForwardModal = (messageId) => { showToast('Forward coming soon', 'info'); };
    window.showReactionPicker = (messageId) => { showToast('Reactions coming soon', 'info'); };

    // Contacts
    window.showContactsView = () => { window.closePopout(); hideAllPanels(); if (DOM.contactsView) DOM.contactsView.style.display = 'flex'; loadContacts(); };
    window.hideContactsView = () => { if (DOM.contactsView) DOM.contactsView.style.display = 'none'; if (activeChat) { if (DOM.chatView) DOM.chatView.style.display = 'flex'; } else { if (DOM.emptyChat) DOM.emptyChat.style.display = 'flex'; } };
    async function loadContacts() { const c = getEl('contactsList'); if (!c) return; try { const r = await fetch('/api/contacts'); const d = await r.json(); if (d.success) { c.innerHTML = d.contacts.map(u => `<div class="contact-item" onclick="openChat('personal',${u.id})"><div class="contact-avatar">${u.username[0].toUpperCase()}</div><div class="contact-info"><div class="contact-name">${escapeHtml(u.display_name)}</div><div class="contact-username">@${escapeHtml(u.username)}</div></div></div>`).join('') || '<div class="empty-state"><p>No contacts</p></div>'; } } catch (e) {} }

    // Global Search
    async function handleGlobalSearch() { const q = DOM.globalSearchInput?.value.trim(); const r = DOM.searchResults; if (!r) return; if (!q||q.length<2) { r.innerHTML = ''; r.classList.remove('active'); return; } try { const res = await fetch(`/api/search/global?q=${encodeURIComponent(q)}`); const d = await res.json(); if (d.success) { let h = ''; if (d.results.users?.length) { h += '<div class="search-result-section">Users</div>'; d.results.users.forEach(u => { h += `<div class="search-result-item" onclick="openChat('personal',${u.id});closeSearchResults()"><div class="search-result-avatar">${u.username[0].toUpperCase()}</div><div class="search-result-info"><div class="search-result-name">${escapeHtml(u.display_name)}</div><div class="search-result-type">@${escapeHtml(u.username)}</div></div></div>`; }); } if (d.results.groups?.length) { h += '<div class="search-result-section">Groups</div>'; d.results.groups.forEach(g => { h += `<div class="search-result-item" onclick="openChat('group',${g.id});closeSearchResults()"><div class="search-result-avatar">👥</div><div class="search-result-info"><div class="search-result-name">${escapeHtml(g.name)}</div><div class="search-result-type">Group</div></div></div>`; }); } r.innerHTML = h || '<div class="search-result-item">No results</div>'; r.classList.add('active'); } } catch (e) {} }
    window.closeSearchResults = () => { DOM.searchResults?.classList.remove('active'); if (DOM.globalSearchInput) DOM.globalSearchInput.value = ''; };

    // Create Group / Channel (with member search)
    window.showCreateGroupView = () => { window.closePopout(); hideAllPanels(); if (DOM.createGroupView) DOM.createGroupView.style.display = 'flex'; selectedMembers = []; const c = getEl('selectedMembers'); if (c) c.innerHTML = ''; };
    window.hideCreateGroupView = () => { if (DOM.createGroupView) DOM.createGroupView.style.display = 'none'; if (activeChat) { if (DOM.chatView) DOM.chatView.style.display = 'flex'; } else { if (DOM.emptyChat) DOM.emptyChat.style.display = 'flex'; } };
    window.createGroup = async () => { const n = getEl('groupName')?.value.trim(); if (!n) { showToast('Enter name', 'error'); return; } const fd = new FormData(); fd.append('name', n); fd.append('member_ids', JSON.stringify(selectedMembers||[])); const a = getEl('groupAvatarInput'); if (a?.files[0]) fd.append('avatar', a.files[0]); try { const r = await fetch('/api/groups/create', { method:'POST', body:fd }); const d = await r.json(); if (d.success) { showToast('Created!', 'success'); hideCreateGroupView(); loadChatList(); openChat('group', d.group.id); } } catch (e) {} };
    window.showCreateChannelView = () => { window.closePopout(); hideAllPanels(); if (DOM.createChannelView) DOM.createChannelView.style.display = 'flex'; };
    window.hideCreateChannelView = () => { if (DOM.createChannelView) DOM.createChannelView.style.display = 'none'; if (activeChat) { if (DOM.chatView) DOM.chatView.style.display = 'flex'; } else { if (DOM.emptyChat) DOM.emptyChat.style.display = 'flex'; } };
    window.createChannel = async () => { const n = getEl('channelName')?.value.trim(); if (!n) { showToast('Enter name', 'error'); return; } const fd = new FormData(); fd.append('name', n); const a = getEl('channelAvatarInput'); if (a?.files[0]) fd.append('avatar', a.files[0]); try { const r = await fetch('/api/channels/create', { method:'POST', body:fd }); const d = await r.json(); if (d.success) { showToast('Created!', 'success'); hideCreateChannelView(); loadChatList(); openChat('channel', d.channel.id); } } catch (e) {} };

    async function handleMemberSearch() {
        const q = getEl('memberSearchInput')?.value.trim();
        const container = getEl('userListForGroup');
        if (!q || q.length < 2) { if (container) container.innerHTML = ''; return; }
        try {
            const r = await fetch(`/api/users?search=${encodeURIComponent(q)}`); const d = await r.json();
            if (d.success && container) {
                container.innerHTML = d.users.map(u => {
                    const sel = selectedMembers.includes(u.id);
                    return `<div class="user-select-item ${sel?'selected':''}" onclick="toggleMemberSelection(${u.id})">
                        <div class="user-select-avatar">${u.username[0].toUpperCase()}</div>
                        <div class="user-select-info"><div class="user-select-name">${escapeHtml(u.display_name)}</div><div class="user-select-username">@${escapeHtml(u.username)}</div></div>
                        ${sel?'<div class="selection-indicator">✓</div>':''}
                    </div>`;
                }).join('');
            }
        } catch (e) {}
    }

    window.toggleMemberSelection = (id) => {
        const idx = selectedMembers.indexOf(id);
        if (idx > -1) selectedMembers.splice(idx, 1); else selectedMembers.push(id);
        renderSelectedMembers();
        handleMemberSearch();
    };

    function renderSelectedMembers() {
        const c = getEl('selectedMembers'); if (!c) return;
        c.innerHTML = selectedMembers.map(id => `<span class="selected-member-tag">User #${id} <button onclick="toggleMemberSelection(${id})">✕</button></span>`).join('');
    }

// Profile
    window.openProfileModal = () => { const m = getEl('profileModal'); if (m) m.style.display = 'flex'; loadProfileData(); };
    window.closeProfileModal = () => { const m = getEl('profileModal'); if (m) m.style.display = 'none'; };
    async function loadProfileData() { try { const r = await fetch('/api/profile'); const d = await r.json(); if (d.success && d.user) { const u = d.user; const dn = getEl('profileDisplayName'), un = getEl('profileUsername'), av = getEl('profileAvatar'), bio = getEl('profileBio'); if (dn) dn.textContent = u.display_name; if (un) un.textContent = '@'+u.username; if (bio) bio.textContent = u.bio||'No bio yet'; if (av) av.innerHTML = u.avatar_url ? `<img src="${u.avatar_url}" class="profile-avatar">` : `<div class="profile-avatar-placeholder">${u.username[0].toUpperCase()}</div>`; } } catch (e) {} }
    window.openEditProfileModal = () => { const m = getEl('editProfileModal'); if (!m) return; const dn = window.currentUserDisplayName; const un = window.currentUserUsername; const bio = getEl('profileBio')?.textContent || ''; const ed = getEl('editDisplayName'), eu = getEl('editUsername'), eb = getEl('editBio'), cc = getEl('bioCharCount'); if (ed) ed.value = dn; if (eu) eu.value = un; if (eb) { eb.value = bio==='No bio yet'?'':bio; if (cc) { cc.textContent = eb.value.length; eb.addEventListener('input', () => cc.textContent = eb.value.length); } } m.style.display = 'flex'; };
    window.closeEditProfileModal = () => { const m = getEl('editProfileModal'); if (m) m.style.display = 'none'; };
    window.saveProfile = async () => { const dn = getEl('editDisplayName')?.value.trim()||''; const un = getEl('editUsername')?.value.trim()||''; const bio = getEl('editBio')?.value.trim()||''; if (!dn) { showToast('Display name required', 'error'); return; } if (!un || un.length<3) { showToast('Username min 3 chars', 'error'); return; } if (!/^[a-zA-Z0-9_]+$/.test(un)) { showToast('Invalid username', 'error'); return; } try { const r = await fetch('/api/profile/update', { method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify({display_name:dn, username:un, bio}) }); const d = await r.json(); if (d.success) { window.currentUserDisplayName = dn; window.currentUserUsername = un; window.currentUserAvatar = un[0].toUpperCase(); updateUI(); closeEditProfileModal(); loadProfileData(); showToast('Profile updated!', 'success'); } } catch (e) { showToast('Error', 'error'); } };
    window.triggerAvatarUpload = () => getEl('avatarInput')?.click();
    window.uploadAvatar = async (i) => { const f = i.files?.[0]; if (!f) return; const fd = new FormData(); fd.append('avatar', f); try { const r = await fetch('/profile/avatar', { method:'POST', body:fd }); const d = await r.json(); if (d.success) { showToast('Avatar updated!', 'success'); loadProfileData(); } } catch (e) {} };

    // File Upload
    window.triggerFileUpload = () => getEl('fileInput')?.click();
    window.handleFileSelect = (i) => { const f = i.files; if (!f?.length) return; const fn = getEl('uploadFileName'); const ua = getEl('uploadArea'); if (fn) fn.textContent = f.length===1 ? f[0].name : `${f.length} files`; if (ua) ua.classList.add('active'); };
    window.uploadFile = async () => { const i = getEl('fileInput'); const f = i?.files; if (!f?.length || !activeChat) { window.cancelUpload(); return; } for (const file of f) { const fd = new FormData(); fd.append('file', file); if (activeChat.type==='personal') fd.append('receiver_id', activeChat.id); else fd.append('group_id', activeChat.id); try { const r = await fetch('/files/upload_file', { method:'POST', body:fd }); const d = await r.json(); if (d.success && DOM.messagesContainer) { if (DOM.messagesContainer.querySelector('.empty-state')) DOM.messagesContainer.innerHTML = ''; DOM.messagesContainer.insertAdjacentHTML('beforeend', renderMessage(d.message)); DOM.messagesContainer.scrollTop = DOM.messagesContainer.scrollHeight; loadChatList(); } } catch (e) {} } window.cancelUpload(); };
    window.cancelUpload = () => { const ua = getEl('uploadArea'); const fi = getEl('fileInput'); if (ua) ua.classList.remove('active'); if (fi) fi.value = ''; };

    // Chat Menu
    window.showChatInfo = () => showToast('Chat info', 'info');
    window.showChatMenu = () => { if (!activeChat) return; const m = document.createElement('div'); m.className = 'modal-overlay'; m.onclick = e => { if (e.target===m) m.remove(); }; m.innerHTML = `<div class="chat-menu-dropdown" style="position:fixed;top:60px;right:20px;background:var(--bg-secondary);border-radius:12px;box-shadow:var(--shadow-lg);padding:8px 0;min-width:200px;z-index:2000"><div class="chat-menu-item" onclick="showChatInfo();this.closest('.modal-overlay').remove()"><span>ℹ️</span> View Info</div><div class="chat-menu-item" onclick="openChatCustomization();this.closest('.modal-overlay').remove()"><span>🎨</span> Customize</div>${activeChat.type==='personal'?`<div class="chat-menu-divider"></div><div class="chat-menu-item danger" onclick="blockUser(${activeChat.id});this.closest('.modal-overlay').remove()"><span>🚫</span> Block</div><div class="chat-menu-item danger" onclick="clearChat(${activeChat.id});this.closest('.modal-overlay').remove()"><span>🗑️</span> Clear</div>`:''}</div>`; document.body.appendChild(m); };
    window.blockUser = async (id) => { if (!confirm('Block?')) return; try { await fetch(`/api/block_user/${id}`, { method:'POST' }); showToast('Blocked', 'success'); activeChat = null; if (DOM.emptyChat) DOM.emptyChat.style.display = 'flex'; if (DOM.chatView) DOM.chatView.style.display = 'none'; loadChatList(); } catch (e) {} };
    window.clearChat = async (id) => { if (!confirm('Clear?')) return; try { await fetch(`/api/clear_chat`, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({chat_id: id}) }); showToast('Cleared', 'success'); if (activeChat?.id===id && DOM.messagesContainer) DOM.messagesContainer.innerHTML = '<div class="empty-state"><p>No messages</p></div>'; loadChatList(); } catch (e) {} };


    window.showAddContactModal = () => { const m = document.createElement('div'); m.className = 'modal-overlay'; m.style.display = 'flex'; m.onclick = e => { if (e.target===m) m.remove(); }; m.innerHTML = `<div class="modal-container" style="max-width:400px"><div class="modal-header"><h3>Add Contact</h3><button class="modal-close" onclick="this.closest('.modal-overlay').remove()">✕</button></div><div class="modal-body"><input type="text" id="addContactSearch" class="modal-input" placeholder="Search username..."><div id="addContactResults" style="max-height:300px;overflow-y:auto"></div></div></div>`; document.body.appendChild(m); const si = getEl('addContactSearch'); if (si) { si.addEventListener('input', debounce(async () => { const q = si.value.trim(); if (q.length<2) return; try { const r = await fetch(`/api/users?search=${encodeURIComponent(q)}`); const d = await r.json(); if (d.success) { const res = getEl('addContactResults'); if (res) res.innerHTML = d.users.map(u => `<div class="contact-item" onclick="openChat('personal',${u.id});closeAllModals()"><div class="contact-avatar">${u.username[0].toUpperCase()}</div><div class="contact-info"><div class="contact-name">${escapeHtml(u.display_name)}</div><div class="contact-username">@${escapeHtml(u.username)}</div></div></div>`).join(''); } } catch (e) {} }, 300)); si.focus(); } };
    window.closeAllModals = () => { document.querySelectorAll('.modal-overlay').forEach(m => m.remove()); const pm = getEl('profileModal'); if (pm) pm.style.display = 'none'; const em = getEl('editProfileModal'); if (em) em.style.display = 'none'; };


    window.showChatsView = () => { hideAllPanels(); if (DOM.emptyChat) DOM.emptyChat.style.display = 'flex'; };
    window.showFollowers = () => showToast('Followers', 'info');
    window.showFollowing = () => showToast('Following', 'info');
    window.showGroups = () => showToast('Groups', 'info');
    window.savePrivacySettings = () => { showToast('Saved', 'success'); window.closePrivacyPanel(); };
    window.toggleMobileSidebar = () => getEl('chatSidebar')?.classList.toggle('mobile-visible');
    window.logout = () => fetch('/api/auth/logout', { method:'POST' }).then(() => location.href='/auth/login');
    window.triggerGroupAvatarUpload = () => getEl('groupAvatarInput')?.click();
    window.previewGroupAvatar = (i) => { if (i.files?.[0]) { const r = new FileReader(); r.onload = e => { const p = getEl('groupAvatarPreview'); if (p) p.innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover;border-radius:50%">`; }; r.readAsDataURL(i.files[0]); } };
    window.triggerChannelAvatarUpload = () => getEl('channelAvatarInput')?.click();
    window.previewChannelAvatar = (i) => { if (i.files?.[0]) { const r = new FileReader(); r.onload = e => { const p = getEl('channelAvatarPreview'); if (p) p.innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover;border-radius:50%">`; }; r.readAsDataURL(i.files[0]); } };

    // Offline sync
    async function syncOfflineMessages() {
        if (offlineQueue.length === 0) return; const toSync = [...offlineQueue]; offlineQueue = [];
        try { const res = await fetch('/api/sync_messages', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ messages: toSync }) }); const data = await res.json(); if (data.success) { data.synced.forEach(item => { const tempEl = document.getElementById(`temp-msg-${item.temp_id}`); if (tempEl) tempEl.outerHTML = renderMessage(item.message); }); loadChatList(); } } catch (e) { offlineQueue.push(...toSync); }
    }
    // Online/offline handled in DOMContentLoaded init above

    // Push notifications (stub)
    async function subscribeToPush() {}

    // Profile completion prompt
    function showProfileCompletionPrompt() {
        const modal = document.createElement('div'); modal.className = 'modal-overlay'; modal.style.display = 'flex';
        modal.innerHTML = `
            <div class="modal-container">
                <div class="modal-header"><h3>Complete Your Profile</h3><button class="modal-close" onclick="this.closest('.modal-overlay').remove()">✕</button></div>
                <div class="modal-body"><p>Add a display name and bio to help friends recognise you.</p>
                    <input type="text" id="onboardDisplayName" class="modal-input" placeholder="Display name" value="${window.currentUserDisplayName}">
                    <textarea id="onboardBio" class="modal-input" placeholder="Bio" rows="3"></textarea>
                </div>
                <div class="modal-footer">
                    <button class="modal-btn modal-btn-secondary" onclick="this.closest('.modal-overlay').remove()">Skip</button>
                    <button class="modal-btn modal-btn-primary" id="saveOnboarding">Save</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        getEl('saveOnboarding').onclick = async () => {
            const dn = getEl('onboardDisplayName').value.trim(); const bio = getEl('onboardBio').value.trim();
            if (dn) { await fetch('/api/profile/update', { method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify({display_name:dn, bio}) }); localStorage.setItem('profile_completed','true'); modal.remove(); showToast('Profile updated!','success'); loadCurrentUser(); }
        };
    }

    // Bot API (Premium)
    window.createBot = async (name, usernameBot, description) => { const res = await fetch('/premium/api/bot/create', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({name, username: usernameBot, description}) }); const data = await res.json(); if (data.success) { alert(`Bot created! Token: ${data.bot.token}`); loadBotsList(); } else { alert(data.error || 'Failed'); } };
    async function loadBotsList() { const container = getEl('botsList'); if (!container) return; try { const res = await fetch('/premium/api/bot/list'); const data = await res.json(); if (data.success && data.bots) { container.innerHTML = data.bots.map(bot => `<div class="bot-item"><div class="bot-info"><div class="bot-avatar">🤖</div><div class="bot-details"><h5>${escapeHtml(bot.name)}</h5><p>@${escapeHtml(bot.username)}</p></div></div><div class="bot-token">Token: ${escapeHtml(bot.token||'••••••••')}</div><div class="bot-actions"><button class="btn-small" onclick="regenerateBotToken(${bot.id})">🔄</button><button class="btn-small btn-danger" onclick="deleteBot(${bot.id})">🗑️</button></div></div>`).join('') || '<p>No bots created yet.</p>'; } } catch (e) {} }
    window.regenerateBotToken = async (botId) => { if (!confirm('Regenerate token?')) return; try { const res = await fetch(`/premium/api/bot/${botId}/regenerate-token`, { method:'POST' }); const data = await res.json(); if (data.success) { alert(`New token: ${data.token}`); loadBotsList(); } else { alert(data.error || 'Failed'); } } catch (e) {} };
    window.deleteBot = async (botId) => { if (!confirm('Delete bot?')) return; try { const res = await fetch(`/premium/api/bot/${botId}`, { method:'DELETE' }); const data = await res.json(); if (data.success) { loadBotsList(); showToast('Bot deleted','success'); } else { alert(data.error || 'Failed'); } } catch (e) {} };
    document.addEventListener('DOMContentLoaded', () => { if (window.currentUserId) setTimeout(loadBotsList, 1000); });
})();