import time
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, session
from sqlalchemy.orm import joinedload, selectinload
from app import db
from app.models import User, Message, Reaction, Reply, Forward, BlockedUser, Chat, ChatMember, File
from app.utils.helpers import get_current_user_id, message_to_dict, validate_emoji, get_animated_file_for_emoji

spav2_messages_bp = Blueprint('spav2_messages', __name__, url_prefix='/api')

_typing_status = {}
_TYPING_TIMEOUT = 5


def _serialize_message(msg, current_user_id=None):
    d = {
        'message_id': msg.id,
        'sender_id': msg.sender_id,
        'receiver_id': msg.receiver_id,
        'content': msg.content,
        'reply_to_id': None,
        'file_path': msg.file_path,
        'file_url': f"/uploads/{msg.file_path}" if msg.file_path else None,
        'file_type': msg.file_type,
        'is_read': msg.is_read,
        'timestamp': msg.timestamp.isoformat() if msg.timestamp else None,
        'edited_at': msg.edited_at.isoformat() if msg.edited_at else None,
        'silent': bool(msg.silent),
        'contact_name': msg.contact_name,
        'contact_phone': msg.contact_phone,
        'send_when_online': bool(msg.send_when_online),
        'reminder_at': msg.reminder_at.isoformat() if msg.reminder_at else None,
        'waveform': msg.waveform,
        'emoji': msg.emoji,
        'emoji_file': msg.emoji_file,
        'emoji_url': f"/uploads/animated_emojis/{msg.emoji_file}" if msg.emoji_file else None,
        'emoji_size': msg.emoji_size or 96,
        'emoji_count': msg.emoji_count or 1,
        'lat': msg.lat,
        'lon': msg.lon,
        'is_location': bool(msg.file_type == 'geo' and msg.lat is not None and msg.lon is not None),
        'reactions': {}
    }
    if msg.sender:
        d['sender_username'] = msg.sender.username
        d['sender_avatar_url'] = msg.sender.avatar_url
    if msg.reply_to:
        d['reply_to_id'] = msg.reply_to.id
    for r in msg.reactions:
        d['reactions'][r.reaction_type] = d['reactions'].get(r.reaction_type, 0) + 1
    return d


@spav2_messages_bp.route('/send_message', methods=['POST'])
def send_personal_message():
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': {'code': 'UNAUTHORIZED', 'message': 'Not authenticated'}}), 401

    data = request.get_json() or {}
    receiver_id = data.get('receiver_id')
    content = data.get('content', '').strip()
    reply_to_id = data.get('reply_to_id')
    lat = data.get('lat')
    lon = data.get('lon')

    # Validate location coordinates if provided
    is_location = False
    if lat is not None or lon is not None:
        try:
            lat = float(lat)
            lon = float(lon)
        except (TypeError, ValueError):
            return jsonify({'success': False, 'error': {'code': 'VALIDATION_ERROR', 'message': 'Invalid location coordinates'}}), 400
        if not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
            return jsonify({'success': False, 'error': {'code': 'VALIDATION_ERROR', 'message': 'Location coordinates out of range'}}), 400
        is_location = True
        content = content or f'{lat},{lon}'

    # Auto-convert single unicode emoji (e.g., 😋) to animated
    emoji_data = None
    if content and not data.get('emoji_file') and not is_location:
        anim_file = get_animated_file_for_emoji(content.strip())
        if anim_file:
            emoji_data, _ = validate_emoji(anim_file, content.strip(), 96, 1)
            if emoji_data:
                content = ''
    if data.get('emoji_file'):
        emoji_data, emoji_err = validate_emoji(
            data.get('emoji_file'), data.get('emoji', ''), data.get('size', 96), data.get('count', 1))
        if emoji_err:
            return jsonify({'success': False, 'error': {'code': 'VALIDATION_ERROR', 'message': emoji_err}}), 400

    errors = {}
    if not isinstance(receiver_id, int):
        errors['receiver_id'] = 'Receiver ID must be an integer'
    if not receiver_id:
        errors['receiver_id'] = 'Receiver ID is required'
    has_file = data.get('file_url') or data.get('file_type')
    if not content and not has_file and not emoji_data and not is_location:
        errors['content'] = 'Message content cannot be empty'
    if len(content) > 5000:
        errors['content'] = 'Message content too long (max 5000 characters)'
    if errors:
        return jsonify({'success': False, 'error': {'code': 'VALIDATION_ERROR', 'message': 'Validation failed', 'fields': errors}}), 400

    if receiver_id != current_user_id:
        if BlockedUser.query.filter_by(user_id=receiver_id, blocked_user_id=current_user_id).first():
            return jsonify({'success': False, 'error': {'code': 'USER_BLOCKED', 'message': 'You cannot send messages to this user'}}), 403

        receiver = User.query.filter_by(id=receiver_id, is_deleted=False).first()
        if not receiver:
            return jsonify({'success': False, 'error': {'code': 'NOT_FOUND', 'message': 'User not found'}}), 404

    a, b = sorted([current_user_id, receiver_id])
    chat = Chat.query.filter_by(chat_type='personal', user1_id=a, user2_id=b).first()
    if not chat:
        chat = Chat(chat_type='personal', user1_id=a, user2_id=b)
        db.session.add(chat)
        db.session.flush()

    msg = Message(content=content, sender_id=current_user_id, receiver_id=receiver_id, chat_id=chat.id, timestamp=datetime.utcnow(), silent=bool(data.get('silent')), send_when_online=bool(data.get('send_when_online')), waveform=data.get('waveform'))
    if is_location:
        msg.file_type = 'geo'
        msg.lat = lat
        msg.lon = lon
    if emoji_data:
        msg.emoji = emoji_data['emoji']
        msg.emoji_file = emoji_data['file']
        msg.emoji_size = emoji_data['size']
        msg.emoji_count = emoji_data['count']
    db.session.add(msg)
    db.session.flush()

    if reply_to_id:
        original = Message.query.get(reply_to_id)
        if original:
            db.session.add(Reply(original_message_id=reply_to_id, reply_message_id=msg.id))

    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify({'success': False, 'error': {'code': 'SERVER_ERROR', 'message': 'Database error'}}), 500
    return jsonify({'success': True, 'data': {'message': _serialize_message(msg, current_user_id)}}), 201


@spav2_messages_bp.route('/messages/locations/<int:chat_id>', methods=['GET'])
def get_chat_locations(chat_id):
    """Return all geo-location messages in a chat (for map display)."""
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': {'code': 'UNAUTHORIZED', 'message': 'Not authenticated'}}), 401

    from app.models import ChatMember, ChannelAdmin, ChatSubscriber
    chat = Chat.query.get(chat_id)
    if not chat:
        return jsonify({'success': False, 'error': {'code': 'NOT_FOUND', 'message': 'Chat not found'}}), 404

    # Access check: personal/group via ChatMember, channel via subscriber/admin/owner
    allowed = False
    if chat.chat_type == 'channel':
        if chat.owner_id == current_user_id:
            allowed = True
        elif ChatSubscriber.query.filter_by(chat_id=chat.id, user_id=current_user_id).first():
            allowed = True
        elif ChannelAdmin.query.filter_by(chat_id=chat.id, user_id=current_user_id).first():
            allowed = True
    elif ChatMember.query.filter_by(chat_id=chat.id, user_id=current_user_id).first():
        allowed = True

    if not allowed:
        return jsonify({'success': False, 'error': {'code': 'FORBIDDEN', 'message': 'No access to this chat'}}), 403

    locations = (Message.query
                 .filter_by(chat_id=chat_id, file_type='geo')
                 .filter(Message.lat.isnot(None), Message.lon.isnot(None))
                 .order_by(Message.timestamp.asc())
                 .all())

    data = []
    for m in locations:
        data.append({
            'message_id': m.id,
            'sender_id': m.sender_id,
            'sender_username': m.sender.username if m.sender else None,
            'sender_avatar_url': m.sender.avatar_url if m.sender else None,
            'lat': m.lat,
            'lon': m.lon,
            'content': m.content,
            'timestamp': m.timestamp.isoformat() if m.timestamp else None,
            'chat_id': m.chat_id,
        })
    return jsonify({'success': True, 'data': {'locations': data, 'chat_id': chat_id}})


@spav2_messages_bp.route('/mark_read/<int:user_id>', methods=['POST'])
def mark_read(user_id):
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': {'code': 'UNAUTHORIZED', 'message': 'Not authenticated'}}), 401

    count = Message.query.filter_by(sender_id=user_id, receiver_id=current_user_id, is_read=False).update({'is_read': True, 'read_at': datetime.utcnow()})
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify({'success': False, 'error': {'code': 'SERVER_ERROR', 'message': 'Database error'}}), 500
    return jsonify({'success': True, 'data': {'marked_count': count, 'peer_user_id': user_id}})


@spav2_messages_bp.route('/messages/<int:message_id>/edit', methods=['POST'])
def edit_message(message_id):
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': {'code': 'UNAUTHORIZED', 'message': 'Not authenticated'}}), 401

    msg = Message.query.get(message_id)
    if not msg:
        return jsonify({'success': False, 'error': {'code': 'NOT_FOUND', 'message': 'Message not found'}}), 404
    if msg.sender_id != current_user_id:
        return jsonify({'success': False, 'error': {'code': 'FORBIDDEN', 'message': 'You can only edit your own messages'}}), 403

    data = request.get_json() or {}
    content = data.get('content', '').strip()
    if not content:
        return jsonify({'success': False, 'error': {'code': 'VALIDATION_ERROR', 'message': 'Content cannot be empty'}}), 400

    msg.content = content
    msg.edited_at = datetime.utcnow()
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify({'success': False, 'error': {'code': 'SERVER_ERROR', 'message': 'Database error'}}), 500
    return jsonify({'success': True, 'data': {'message': _serialize_message(msg, current_user_id)}})


@spav2_messages_bp.route('/typing/<chat_type>/<int:chat_id>', methods=['POST'])
def set_typing(chat_type, chat_id):
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': {'code': 'UNAUTHORIZED', 'message': 'Not authenticated'}}), 401

    key = f"{chat_type}_{chat_id}"
    if key not in _typing_status:
        _typing_status[key] = {}
    _typing_status[key][current_user_id] = time.time()

    expires_at = datetime.utcfromtimestamp(time.time() + _TYPING_TIMEOUT).isoformat()
    return jsonify({'success': True, 'data': {
        'chat_type': chat_type,
        'chat_id': str(chat_id),
        'is_typing': True,
        'expires_at': expires_at
    }})


@spav2_messages_bp.route('/reactions/add', methods=['POST'])
def add_reaction():
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': {'code': 'UNAUTHORIZED', 'message': 'Not authenticated'}}), 401

    data = request.get_json() or {}
    message_id = data.get('message_id')
    reaction_type = data.get('reaction_type')

    if not reaction_type or not reaction_type.strip():
        return jsonify({'success': False, 'error': {'code': 'VALIDATION_ERROR', 'message': 'Reaction type is required'}}), 400
    reaction_type = reaction_type.strip()

    existing = Reaction.query.filter_by(message_id=message_id, user_id=current_user_id, reaction_type=reaction_type).first()
    if existing:
        db.session.delete(existing)
        has_reacted = False
    else:
        db.session.add(Reaction(message_id=message_id, user_id=current_user_id, reaction_type=reaction_type))
        has_reacted = True
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify({'success': False, 'error': {'code': 'SERVER_ERROR', 'message': 'Database error'}}), 500

    count = Reaction.query.filter_by(message_id=message_id, reaction_type=reaction_type).count()
    return jsonify({'success': True, 'data': {
        'message_id': message_id,
        'reaction_type': reaction_type,
        'has_reacted': has_reacted,
        'reaction_count': count
    }})


@spav2_messages_bp.route('/messages/<int:message_id>/delete', methods=['POST'])
def delete_message(message_id):
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': {'code': 'UNAUTHORIZED', 'message': 'Not authenticated'}}), 401

    msg = Message.query.get(message_id)
    if not msg:
        return jsonify({'success': False, 'error': {'code': 'NOT_FOUND', 'message': 'Message not found'}}), 404
    if msg.sender_id != current_user_id:
        return jsonify({'success': False, 'error': {'code': 'FORBIDDEN', 'message': 'You can only delete your own messages'}}), 403

    msg.is_deleted = True
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify({'success': False, 'error': {'code': 'SERVER_ERROR', 'message': 'Database error'}}), 500
    return jsonify({'success': True, 'data': {'message_id': message_id}})


@spav2_messages_bp.route('/reactions/<int:message_id>', methods=['GET'])
def get_reactions(message_id):
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': {'code': 'UNAUTHORIZED', 'message': 'Not authenticated'}}), 401

    reactions = Reaction.query.options(selectinload(Reaction.user)).filter_by(message_id=message_id).all()
    grouped = {}
    for r in reactions:
        if r.reaction_type not in grouped:
            grouped[r.reaction_type] = []
        grouped[r.reaction_type].append({'user_id': r.user_id, 'username': r.user.username if r.user else None})

    result = []
    for rtype, users in grouped.items():
        has_reacted = any(u['user_id'] == current_user_id for u in users)
        result.append({
            'reaction_type': rtype,
            'count': len(users),
            'users': users,
            'has_reacted': has_reacted
        })

    return jsonify({'success': True, 'data': {'message_id': message_id, 'reactions': result}})


@spav2_messages_bp.route('/emojis', methods=['GET'])
def list_emojis():
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': {'code': 'UNAUTHORIZED', 'message': 'Not authenticated'}}), 401

    import os
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    base = os.path.join(root, 'uploads', 'animated_emojis')
    static_base = os.path.join(root, 'static', 'stickers', 'animatedemojies')
    manifest_path = os.path.join(root, 'static', 'stickers', '_manifest.json')
    emojis = []
    seen = set()
    # Prefer server storage (uploads/animated_emojis)
    check_base = base if os.path.isdir(base) and os.listdir(base) else static_base
    check_url = "/uploads/animated_emojis" if check_base == base else "/static/stickers/animatedemojies"
    if os.path.isfile(manifest_path):
        try:
            import json
            with open(manifest_path, 'r', encoding='utf-8') as fh:
                manifest = json.load(fh)
            for s in manifest.get('animatedemojies', {}).get('stickers', []):
                fname = s.get('file')
                if fname and fname.endswith('.webp') and fname not in seen:
                    # Only include if file exists in server storage or static
                    fpath = os.path.join(check_base, fname)
                    if os.path.isfile(fpath):
                        seen.add(fname)
                        emojis.append({'file': fname, 'emoji': s.get('emoji', ''), 'url': f"{check_url}/{fname}"})
        except Exception:
            emojis = []
    if not emojis and os.path.isdir(check_base):
        for fname in sorted(os.listdir(check_base)):
            if fname.endswith('.webp'):
                emojis.append({'file': fname, 'emoji': '', 'url': f"{check_url}/{fname}"})
    return jsonify({'success': True, 'data': {'emojis': emojis}})


# ── Contact sharing (Telegram parity) ─────────────────────

@spav2_messages_bp.route('/share_contact', methods=['POST'])
def share_contact():
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': {'code': 'UNAUTHORIZED', 'message': 'Not authenticated'}}), 401

    data = request.get_json() or {}
    receiver_id = data.get('receiver_id')
    contact_name = (data.get('contact_name') or data.get('name') or '').strip()
    contact_phone = (data.get('contact_phone') or data.get('phone') or '').strip()

    if not isinstance(receiver_id, int) or not receiver_id:
        return jsonify({'success': False, 'error': {'code': 'VALIDATION_ERROR', 'message': 'receiver_id required'}}), 400
    if not contact_name or not contact_phone:
        uid = data.get('user_id')
        if uid:
            u = User.query.get(uid)
            if u:
                contact_name = u.display_name or u.username
                contact_phone = getattr(u, 'phone', None) or contact_phone or ''
    if not contact_name:
        return jsonify({'success': False, 'error': {'code': 'VALIDATION_ERROR', 'message': 'contact_name required'}}), 400

    a, b = sorted([current_user_id, receiver_id])
    chat = Chat.query.filter_by(chat_type='personal', user1_id=a, user2_id=b).first()
    if not chat:
        chat = Chat(chat_type='personal', user1_id=a, user2_id=b)
        db.session.add(chat)
        db.session.flush()

    msg = Message(content=None, sender_id=current_user_id, receiver_id=receiver_id,
                  chat_id=chat.id, timestamp=datetime.utcnow(),
                  contact_name=contact_name, contact_phone=contact_phone)
    db.session.add(msg)
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify({'success': False, 'error': {'code': 'SERVER_ERROR', 'message': 'Database error'}}), 500
    return jsonify({'success': True, 'data': {'message': _serialize_message(msg, current_user_id)}}), 201


# ── Message reminders (Telegram parity) ───────────────────

@spav2_messages_bp.route('/messages/<int:message_id>/remind', methods=['POST'])
def remind_message(message_id):
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': {'code': 'UNAUTHORIZED', 'message': 'Not authenticated'}}), 401

    msg = Message.query.get(message_id)
    if not msg:
        return jsonify({'success': False, 'error': {'code': 'NOT_FOUND', 'message': 'Message not found'}}), 404

    data = request.get_json() or {}
    when = data.get('when') or data.get('reminder_at')
    if when:
        try:
            from datetime import datetime as _dt
            reminder_time = _dt.fromisoformat(when.replace('Z', '+00:00')).replace(tzinfo=None)
        except Exception:
            return jsonify({'success': False, 'error': {'code': 'VALIDATION_ERROR', 'message': 'Invalid when (ISO datetime)'}}), 400
    else:
        # default: 1 hour from now
        reminder_time = datetime.utcnow() + timedelta(hours=1)

    msg.reminder_at = reminder_time
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify({'success': False, 'error': {'code': 'SERVER_ERROR', 'message': 'Database error'}}), 500
    return jsonify({'success': True, 'data': {'message_id': message_id, 'reminder_at': reminder_time.isoformat()}})


# ── GIF send (Telegram parity) ────────────────────────────

@spav2_messages_bp.route('/send_gif', methods=['POST'])
def send_gif():
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': {'code': 'UNAUTHORIZED', 'message': 'Not authenticated'}}), 401

    data = request.get_json() or {}
    receiver_id = data.get('receiver_id')
    chat_id = data.get('chat_id')
    gif_url = (data.get('gif_url') or data.get('url') or '').strip()
    if not gif_url:
        return jsonify({'success': False, 'error': {'code': 'VALIDATION', 'message': 'gif_url required'}}), 400

    if not chat_id:
        if not isinstance(receiver_id, int) or not receiver_id:
            return jsonify({'success': False, 'error': {'code': 'VALIDATION', 'message': 'receiver_id or chat_id required'}}), 400
        a, b = sorted([current_user_id, receiver_id])
        chat = Chat.query.filter_by(chat_type='personal', user1_id=a, user2_id=b).first()
        if not chat:
            chat = Chat(chat_type='personal', user1_id=a, user2_id=b)
            db.session.add(chat)
            db.session.flush()
        chat_id = chat.id

    from .features import _chat_access
    if not _chat_access(current_user_id, chat_id):
        return jsonify({'success': False, 'error': {'code': 'FORBIDDEN', 'message': 'You are not in this chat'}}), 403

    msg = Message(content=None, sender_id=current_user_id, chat_id=chat_id,
                  file_type='gif', file_path=gif_url, file_name='gif',
                  timestamp=datetime.utcnow())
    db.session.add(msg)
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify({'success': False, 'error': {'code': 'SERVER_ERROR', 'message': 'Database error'}}), 500
    return jsonify({'success': True, 'data': {'message': _serialize_message(msg, current_user_id)}}), 201


# ── Voice message send (Telegram parity) ─────────────────

@spav2_messages_bp.route('/send_voice', methods=['POST'])
def send_voice():
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': {'code': 'UNAUTHORIZED', 'message': 'Not authenticated'}}), 401

    data = request.get_json() or {}
    receiver_id = data.get('receiver_id')
    chat_id = data.get('chat_id')
    file_url = (data.get('file_url') or data.get('file_path') or '').strip()
    duration = data.get('duration')
    waveform = data.get('waveform')

    if not file_url:
        return jsonify({'success': False, 'error': {'code': 'VALIDATION', 'message': 'file_url required'}}), 400

    if not chat_id:
        if not isinstance(receiver_id, int) or not receiver_id:
            return jsonify({'success': False, 'error': {'code': 'VALIDATION', 'message': 'receiver_id or chat_id required'}}), 400
        a, b = sorted([current_user_id, receiver_id])
        chat = Chat.query.filter_by(chat_type='personal', user1_id=a, user2_id=b).first()
        if not chat:
            chat = Chat(chat_type='personal', user1_id=a, user2_id=b)
            db.session.add(chat)
            db.session.flush()
        chat_id = chat.id

    from .features import _chat_access
    if not _chat_access(current_user_id, chat_id):
        return jsonify({'success': False, 'error': {'code': 'FORBIDDEN', 'message': 'You are not in this chat'}}), 403

    msg = Message(content=None, sender_id=current_user_id, chat_id=chat_id,
                  file_type='voice', file_path=file_url, file_name='voice.ogg',
                  file_size=data.get('file_size'), waveform=waveform,
                  timestamp=datetime.utcnow())
    db.session.add(msg)
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify({'success': False, 'error': {'code': 'SERVER_ERROR', 'message': 'Database error'}}), 500
    return jsonify({'success': True, 'data': {'message': _serialize_message(msg, current_user_id)}}), 201
