import secrets
import os
from datetime import datetime
from flask import Blueprint, request, jsonify

from app import db
from app.models import User, Chat, ChatSubscriber, ChannelAdmin, Message, BlockedUser
from app.utils.helpers import get_current_user_id, get_current_user, message_to_dict

spa_channels_bp = Blueprint('spa_channels', __name__, url_prefix='/api')


# ==================== ENDPOINTS ====================

@spa_channels_bp.route('/channels/create', methods=['POST'])
def create_channel():
    """
    Create a new channel. Accepts JSON or multipart form data (with optional avatar).
    """
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401

    if request.is_json:
        data = request.get_json()
        name = data.get('name', '').strip()
        description = data.get('description', '')
        is_public = data.get('is_public', True)
    else:
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '')
        is_public = request.form.get('is_public', 'true').lower() == 'true'

    if not name or len(name) < 3:
        return jsonify({'success': False, 'error': 'Channel name must be at least 3 characters'}), 400

    invite_link = secrets.token_urlsafe(16)
    new_chat = Chat(
        chat_type='channel',
        name=name,
        description=description,
        owner_id=current_user_id,
        is_public=is_public,
        invite_link=invite_link,
        created_at=datetime.utcnow()
    )
    db.session.add(new_chat)
    db.session.flush()

    # Handle avatar upload (if any)
    if 'avatar' in request.files:
        file = request.files['avatar']
        if file and file.filename:
            try:
                from PIL import Image
                ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else 'jpg'
                filename = f"channel_{new_chat.id}_{secrets.token_urlsafe(8)}.{ext}"
                upload_dir = os.path.join('uploads', 'channels')
                os.makedirs(upload_dir, exist_ok=True)
                file_path = os.path.join(upload_dir, filename)
                img = Image.open(file)
                img.thumbnail((200, 200))
                img.save(file_path)
                new_chat.avatar_url = f"/uploads/channels/{filename}"
            except:
                ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else 'jpg'
                filename = f"channel_{new_chat.id}_{secrets.token_urlsafe(8)}.{ext}"
                upload_dir = os.path.join('uploads', 'channels')
                os.makedirs(upload_dir, exist_ok=True)
                file_path = os.path.join(upload_dir, filename)
                file.save(file_path)
                new_chat.avatar_url = f"/uploads/channels/{filename}"

    # Creator automatically subscribes
    db.session.add(ChatSubscriber(user_id=current_user_id, chat_id=new_chat.id))
    db.session.commit()

    return jsonify({
        'success': True,
        'channel': {
            'id': new_chat.id,
            'name': new_chat.name,
            'avatar_url': new_chat.avatar_url,
            'invite_link': new_chat.invite_link
        }
    })


@spa_channels_bp.route('/channels/<int:channel_id>', methods=['GET'])
def get_channel(channel_id):
    """
    Get channel details, subscriber count, and current user's subscription status.
    """
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401

    chat = Chat.query.get(channel_id)
    if not chat or chat.chat_type != 'channel':
        return jsonify({'success': False, 'error': 'Channel not found'}), 404

    subscription = ChatSubscriber.query.filter_by(user_id=current_user_id, chat_id=channel_id).first()
    subscriber_count = ChatSubscriber.query.filter_by(chat_id=channel_id).count()
    is_owner = chat.owner_id == current_user_id

    return jsonify({
        'success': True,
        'channel': {
            'id': chat.id,
            'name': chat.name,
            'description': chat.description,
            'avatar_url': chat.avatar_url,
            'is_public': chat.is_public,
            'invite_link': chat.invite_link,
            'owner_id': chat.owner_id,
            'subscriber_count': subscriber_count,
        },
        'is_subscribed': subscription is not None,
        'is_owner': is_owner,
        'can_post': is_owner or (subscription is not None)
    })


@spa_channels_bp.route('/channel_messages/<int:channel_id>', methods=['GET'])
def get_channel_messages(channel_id):
    """
    Retrieve messages for a channel. Only subscribers can view.
    """
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401

    subscription = ChatSubscriber.query.filter_by(user_id=current_user_id, chat_id=channel_id).first()
    chat = Chat.query.get(channel_id)
    if not subscription and (not chat or chat.owner_id != current_user_id):
        return jsonify({'success': False, 'error': 'Not subscribed'}), 403

    after_id = request.args.get('after', 0, type=int)
    limit = request.args.get('limit', 50, type=int)

    messages = Message.query.filter_by(chat_id=channel_id) \
        .filter(Message.id > after_id) \
        .order_by(Message.timestamp.asc()) \
        .limit(limit).all()

    from app.utils.helpers import message_to_dict
    result = [message_to_dict(msg, current_user_id) for msg in messages]
    return jsonify({'success': True, 'messages': result})


@spa_channels_bp.route('/send_channel_message', methods=['POST'])
def send_channel_message():
    """
    Post a message to a channel (only owner can post, or admins if implemented).
    """
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401

    if request.is_json:
        data = request.get_json()
        channel_id = data.get('channel_id')
        content = data.get('content', '').strip()
    else:
        channel_id = request.form.get('channel_id')
        content = request.form.get('content', '').strip()

    if not channel_id or not content:
        return jsonify({'success': False, 'error': 'channel_id and content are required'}), 400

    chat = Chat.query.get(int(channel_id))
    if not chat or chat.chat_type != 'channel':
        return jsonify({'success': False, 'error': 'Channel not found'}), 404

    if chat.owner_id != current_user_id:
        return jsonify({'success': False, 'error': 'Only the owner can post'}), 403

    new_message = Message(
        sender_id=current_user_id,
        chat_id=chat.id,
        receiver_id=current_user_id,
        content=content,
        timestamp=datetime.utcnow()
    )
    db.session.add(new_message)
    db.session.commit()

    from app.utils.helpers import message_to_dict
    return jsonify({'success': True, 'message': message_to_dict(new_message, current_user_id)})


@spa_channels_bp.route('/channels/<int:channel_id>/subscribe', methods=['POST'])
def subscribe_channel(channel_id):
    """Subscribe to a channel."""
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401

    existing = ChatSubscriber.query.filter_by(user_id=current_user_id, chat_id=channel_id).first()
    if existing:
        return jsonify({'success': True, 'already_subscribed': True})

    db.session.add(ChatSubscriber(user_id=current_user_id, chat_id=channel_id))
    db.session.commit()
    return jsonify({'success': True, 'subscribed': True})


@spa_channels_bp.route('/channels/<int:channel_id>/unsubscribe', methods=['POST'])
def unsubscribe_channel(channel_id):
    """Unsubscribe from a channel (owner cannot unsubscribe)."""
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401

    chat = Chat.query.get(channel_id)
    if chat and chat.owner_id == current_user_id:
        return jsonify({'success': False, 'error': 'Owner cannot unsubscribe'}), 400

    ChatSubscriber.query.filter_by(user_id=current_user_id, chat_id=channel_id).delete()
    db.session.commit()
    return jsonify({'success': True, 'subscribed': False})


@spa_channels_bp.route('/channels/<int:channel_id>/update', methods=['POST'])
def update_channel(channel_id):
    """Update channel name, description, or public/private setting. Owner only."""
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401

    chat = Chat.query.get(channel_id)
    if not chat or chat.owner_id != current_user_id:
        return jsonify({'success': False, 'error': 'Insufficient permissions'}), 403

    data = request.get_json() or {}
    if 'name' in data:
        chat.name = data['name']
    if 'description' in data:
        chat.description = data['description']
    if 'is_public' in data:
        chat.is_public = data['is_public']

    db.session.commit()
    return jsonify({'success': True})


# ==================== CHANNEL ADMINS (NyEXGRAM feature) ====================

@spa_channels_bp.route('/channels/<int:channel_id>/admins', methods=['GET'])
def get_channel_admins(channel_id):
    """List all admins of a channel."""
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401

    chat = Chat.query.get(channel_id)
    if not chat or chat.chat_type != 'channel':
        return jsonify({'success': False, 'error': 'Channel not found'}), 404

    admins = []
    owner = User.query.get(chat.owner_id)
    if owner:
        admins.append({
            'user_id': owner.id,
            'username': owner.username,
            'display_name': owner.display_name or owner.username,
            'avatar_url': owner.avatar_url,
            'can_post': True,
            'can_edit': True,
            'can_delete': True,
            'can_add_admins': True
        })
    for ca in ChannelAdmin.query.filter_by(chat_id=channel_id).all():
        user = User.query.get(ca.user_id)
        if user:
            admins.append({
                'user_id': user.id,
                'username': user.username,
                'display_name': user.display_name or user.username,
                'avatar_url': user.avatar_url,
                'can_post': ca.can_post,
                'can_edit': ca.can_edit,
                'can_delete': ca.can_delete,
                'can_add_admins': ca.can_add_admins
            })

    return jsonify({'success': True, 'admins': admins})


@spa_channels_bp.route('/channels/<int:channel_id>/admins', methods=['POST'])
def add_channel_admin(channel_id):
    """Add a user as admin (owner only)."""
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401

    chat = Chat.query.get(channel_id)
    if not chat or chat.owner_id != current_user_id:
        return jsonify({'success': False, 'error': 'Insufficient permissions'}), 403

    data = request.get_json() or {}
    user_id = data.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'error': 'user_id required'}), 400

    if user_id == current_user_id:
        return jsonify({'success': False, 'error': 'Owner is already an admin'}), 400

    existing = ChannelAdmin.query.filter_by(chat_id=channel_id, user_id=user_id).first()
    if existing:
        return jsonify({'success': True, 'already_admin': True})

    permissions = data.get('permissions', {})
    admin = ChannelAdmin(
        chat_id=channel_id,
        user_id=user_id,
        can_post=permissions.get('can_post', True),
        can_edit=permissions.get('can_edit', False),
        can_delete=permissions.get('can_delete', False),
        can_add_admins=permissions.get('can_add_admins', False)
    )
    db.session.add(admin)
    db.session.commit()
    return jsonify({'success': True})


@spa_channels_bp.route('/channels/<int:channel_id>/admins/<int:user_id>', methods=['DELETE'])
def remove_channel_admin(channel_id, user_id):
    """Remove an admin (owner only)."""
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401

    chat = Chat.query.get(channel_id)
    if not chat or chat.owner_id != current_user_id:
        return jsonify({'success': False, 'error': 'Insufficient permissions'}), 403

    if user_id == chat.owner_id:
        return jsonify({'success': False, 'error': 'Cannot remove owner'}), 400

    admin = ChannelAdmin.query.filter_by(chat_id=channel_id, user_id=user_id).first()
    if not admin:
        return jsonify({'success': False, 'error': 'Admin not found'}), 404

    db.session.delete(admin)
    db.session.commit()
    return jsonify({'success': True})


@spa_channels_bp.route('/channels/<int:channel_id>/delete', methods=['POST'])
def delete_channel(channel_id):
    """Delete a channel (owner only)."""
    current_user_id = get_current_user_id()
    if not current_user_id:
        return jsonify({'success': False, 'error': 'Not authenticated'}), 401

    chat = Chat.query.get(channel_id)
    if not chat or chat.owner_id != current_user_id:
        return jsonify({'success': False, 'error': 'Insufficient permissions'}), 403

    Message.query.filter_by(chat_id=channel_id).delete()
    ChatSubscriber.query.filter_by(chat_id=channel_id).delete()
    db.session.delete(chat)
    db.session.commit()

    return jsonify({'success': True})